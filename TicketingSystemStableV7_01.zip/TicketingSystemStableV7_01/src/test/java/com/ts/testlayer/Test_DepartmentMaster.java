package com.ts.testlayer;

import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.Test;

import com.sharedutils.MasterDto;
import com.ts.utils.MasterClass;

public class Test_DepartmentMaster extends MasterClass {
	ITestResult result;

	@Test(enabled = true, groups = { "admin", "Master", "Department Master", "Functionality" })
	public void addDepartment() throws Throwable {
//		login();
		List<MasterDto> masterDtos = excelHelper
				.readAllExcelDataAndSetToDto(dataPath + "Testdata_DepartmentMaster.xlsx", "Add");
		for (MasterDto masterDto : masterDtos) {
			try {
				departmentMaster.addDepartment(masterDto);
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				reportHelper.generateExcelReport(test, result, masterDto);
			}
		}
	}

	@Test(enabled = true, groups = { "admin", "Master", "Department Master", "Validation" })
	public void editDesignation() throws Throwable {
//		login();
		List<MasterDto> masterDtos = excelHelper
				.readAllExcelDataAndSetToDto(dataPath + "Testdata_DepartmentMaster.xlsx", "Edit");
		for (MasterDto masterDto : masterDtos) {
			try {
				departmentMaster.editDepartment(masterDto);
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				// Generate Excel report for this test case
				reportHelper.generateExcelReport(test, result, masterDto);
			}
		}

	}

}
