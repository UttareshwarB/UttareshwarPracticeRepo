package com.ts.testlayer;

import java.util.Map;

import org.testng.annotations.Test;

import com.ts.utils.MasterClass;

public class Test_CustomerMaster extends MasterClass {

	@Test(enabled = false)
	public void addCustomer() throws Throwable {
		login();

		for (int rowIndex = 1; rowIndex <= excelHelper.rowCountExcel(dataPath + "Testdata_CustomerMaster_29Nov.xlsx",
				"Add"); rowIndex++) {

			// countryMasterPage.addCountry().click();

			Map<String, String> rowData = excelHelper
					.readExcelDataAndMap(dataPath + "Testdata_CustomerMaster_29Nov.xlsx", "Add", rowIndex);

			for (Map.Entry<String, String> entryObj : rowData.entrySet()) {
				masterDto.setAttribute(entryObj.getKey(), entryObj.getValue());
				System.out.printf(entryObj.getKey(), entryObj.getValue());
			}

			// userMaster.addUser();
			// CityMasters.addCity
			customerMaster.addCustomer(masterDto);
		}
	}

	@Test(enabled = true)
	public void editCustomer() throws Throwable {
		login();

		for (int rowIndex = 1; rowIndex <= excelHelper.rowCountExcel(dataPath + "Testdata_CustomerMasterNew.xlsx",
				"EditNew"); rowIndex++) {

			// countryMasterPage.addCountry().click();

//				Map<String, String> rowData = excelHelper.readExcelDataAndMap(dataPath + "Testdata_CustomerMasterNew.xlsx", "EditNew",
//						rowIndex);
			Map<String, String> rowData = excelHelper.readExcelDataAndMap(dataPath + "Testdata_CustomerMasterNew.xlsx",
					"EditNew", rowIndex);

			for (Map.Entry<String, String> entryObj : rowData.entrySet()) {
				masterDto.setAttribute(entryObj.getKey(), entryObj.getValue());
				System.out.printf(entryObj.getKey(), entryObj.getValue());
			}

			// userMaster.addUser();.
			// CityMasters.addCity
			customerMaster.editCustomer(masterDto);
		}
	}

}
