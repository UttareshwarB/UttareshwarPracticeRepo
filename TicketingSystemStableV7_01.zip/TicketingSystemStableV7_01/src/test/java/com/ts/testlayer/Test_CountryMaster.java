package com.ts.testlayer;

import java.util.List;

import org.testng.ITestResult;
import org.testng.annotations.Test;

import com.sharedutils.MasterDto;
import com.sharedutils.ReportsHelper;
import com.ts.utils.MasterClass;

public class Test_CountryMaster extends MasterClass {
	ITestResult result;
	ReportsHelper reportsHelper = new ReportsHelper();

	@Test(priority = 1, enabled = true, groups = { "admin", "Master", "Country Master", "Functionality" })
	public void addCountry() throws Throwable {
		// "Type :Master", "Module : Master", " SubModule : Country Master",
//		login();
		List<MasterDto> masterDtos = excelHelper.getTestData(countryMasterSheet, "Add_Functional");
		// Iterate over the list and process each MasterDto
		for (MasterDto masterDto : masterDtos) {

			try {
				test = reportHelper.createTestCase(test, extentReports, masterDto);
				countryMaster.addCountry(test, masterDto);
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				reportHelper.generateExcelReport(test, result, masterDto);
			}
		}
	}

	@Test(priority = 2, enabled = true, groups = {"admin", "Master", "Country Master", "Validation" })
	public void editCountry() throws Exception, Throwable {
//		login();
		List<MasterDto> masterDtos = excelHelper.readAllExcelDataAndSetToDto(dataPath + "Testdata_CountryMaster.xlsx",
				"Edit");
		// Iterate over the list and process each MasterDto
		for (MasterDto masterDto : masterDtos) {
			try {
				test = reportHelper.createTestCase(test, extentReports, masterDto);
				countryMaster.editCountry(masterDto);
			} catch (Throwable e) {
				e.printStackTrace();
			} finally {
				reportHelper.generateExcelReport(test, result, masterDto);
			}
		}
	}

}
