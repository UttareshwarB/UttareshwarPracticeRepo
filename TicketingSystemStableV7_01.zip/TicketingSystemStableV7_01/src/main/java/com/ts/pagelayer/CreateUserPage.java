package com.ts.pagelayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ts.utils.MasterClass;

public class CreateUserPage extends MasterClass{

	
	
	
//	@FindBy (xpath = "//select[@id='account_for']")
	@FindBy(xpath = "//select[@id='account_for']")
	WebElement accountFor;
	public WebElement accountFor()
	{
		return accountFor;
	}
	
	
	
	
	@FindBy (xpath = "//input[@id='first_name']")
	WebElement firstName;
	public WebElement firstName()
	{
		return firstName;
	}

	@FindBy (xpath = "//input[@id='middle_name']")
	WebElement middlename;
	public WebElement middlename()
	{
		return middlename;
	}
	
	@FindBy (xpath = "//input[@id='last_name']")
	WebElement lastName;
	public WebElement lastName()
	{
		return lastName;
	}
	
	@FindBy (xpath = "//input[@id='email_id']")
	WebElement emailId;
	public WebElement emailId()
	{
		return emailId;
	}
	
	@FindBy (xpath = "//input[@id='user_name']")
	WebElement userName;
	public WebElement userName()
	{
		return userName;
	}
	
	@FindBy (xpath = "//input[@id='contact_no']")
	WebElement contactNo;
	public WebElement contactNo()
	{
		return contactNo;
	}
	
	@FindBy (xpath = "//input[@name='check1']")
	WebElement checkForSame;
	public WebElement checkForSame()
	{
		return checkForSame;
	}
	
	@FindBy (xpath = "//input[@id='whats_app_contact_no']")
	WebElement whatsAppNumber;
	public WebElement whatsAppNumber()
	{
		return whatsAppNumber;
	}
	
	@FindBy (xpath = "//input[@name='check1']")
	WebElement checkboxwhatsApp;
	public WebElement checkboxwhatsApp()
	{
		return checkboxwhatsApp;
	}
	
	@FindBy (xpath = "//input[@id='password']")
	WebElement passWord;
	public WebElement passWord()
	{
		return passWord;
	}
	
	@FindBy (xpath = "//input[@placeholder='confirmed_password']")
	WebElement cPassword;
	public WebElement cPassword()
	{
		return cPassword;
	}
	
	@FindBy (xpath = "//b[contains(text(),'Select Role')]/parent::label/following-sibling::div[1]/descendant::input")
	WebElement roleSelect;
	public WebElement roleSelect()
	{
		return roleSelect;
	}
	
	@FindBy (xpath = "//b[contains(text(),'Select Role')]/parent::label/following-sibling::div[2]/descendant::input")
	WebElement designationSelect;
	public WebElement designationSelect()
	{
		return designationSelect;
	}
	
	@FindBy (xpath = "//button[text()='User Setting']")
	WebElement userSettingMenu;
	public WebElement userSettingMenu()
	{
		return userSettingMenu;
	}
	
	@FindBy (xpath = "//tbody/child::tr/child::td[2]/descendant::input[1]")
	WebElement department;
	public WebElement department()
	{
		return department;
	}
	
	@FindBy (xpath = "//tbody/child::tr/child::td[3]/descendant::input[1]")
	WebElement ticketType;
	public WebElement ticketType()
	{
		return ticketType;
	}
	
	@FindBy (xpath = "//button[text()='Submit']")
	WebElement submit;
	public WebElement submit()
	{
		return submit;
	}
	
	@FindBy (xpath = "//a[contains(text(),'Add User')]")
	WebElement add_User;
	public WebElement add_User()
	{
		return add_User;
	}
	
	@FindBy (xpath = "//textarea[@id='address']")
	WebElement address;
	public WebElement address()
	{
		return address;
	}
	
	@FindBy (xpath = "//b[contains(text(),'Country')]/parent::label/following-sibling::div/descendant::input[@type='text']")
	WebElement country;
	public WebElement country()
	{
		return country;
	}
	
	@FindBy (xpath = "//input[@id='pincode']")
	WebElement pincode;
	public WebElement pincode()
	{
		return pincode;
	}
	
	@FindBy (xpath = "(//div[@id='state_id']//input)[1]")
	WebElement state;
	public WebElement state()
	{
		return state;
	}
	
	@FindBy (xpath = "(//div[@id='city_id']//input)[1]")
	WebElement city;
	public WebElement city()
	{
		return city;
	}
	
	
	@FindBy (xpath = "//span[text()='Next']")
	WebElement nextButton;
	public WebElement nextButton()
	{
		return nextButton;
	}		
	
	@FindBy (xpath = "//input[@id='ticket_passing_authority_0']")
	WebElement passingAuthority;
	public WebElement passingAuthority()
	{
		return passingAuthority;
	}
	
	@FindBy (xpath = "//input[@id='is_default_0']")
	WebElement isDefault;
	public WebElement isDefault()
	{
		return isDefault; 
	}
	
	
	@FindBy (xpath = "//a[text()='Cancel']")
	WebElement cancelbtn;
	public WebElement cancelbtn()
	{
		return cancelbtn;
	}
	
	
//	public WebElement ele()
//	{
//		return ele;
//	}
	
	public CreateUserPage ()
	{
		PageFactory.initElements(driver, this);
	}

}
