package com.ts.pagelayer;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;

import com.ts.utils.MasterClass;

public class NavigateToPage extends MasterClass{

	boolean visitMaster=false;

	public NavigateToPage() {
		PageFactory.initElements(driver, this);
	}

	public void billTypeMasterPage() throws InterruptedException
	{

		try {

			homePage.billTypeMaster().click(); 
			Thread.sleep(1000); 
		} catch (Exception e) {
			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
			homePage.billCheckingMaster().click();
			Thread.sleep(1000); 

			genericHelper.scrollingTillWebElement(homePage.vendorMaster());
			Thread.sleep(1000);
			homePage.billTypeMaster().click();		}

	}

	public void customerTypeMasterPage() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(1000);

		homePage.master().click();
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.customerTypeMaster());
		Thread.sleep(1000);
		homePage.customerTypeMaster().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Customer Master page");
	}


	public void consolidatedView() throws InterruptedException
	{
		genericHelper.scrollingTillWebElement(homePage.projectManagement());

		genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(500);

		homePage.projectManagement().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.consolidatedView());
		Thread.sleep(500);
		homePage.consolidatedView().click();
		Thread.sleep(500);	
	}

	public void generalSettingsPage() throws InterruptedException, IOException {

		genericHelper.scrollingTillWebElement(homePage.setting());

		//	genericHelper.clickWithjavascriptExecutor(homePage.setting());

		homePage.setting().click(); 
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.generalSetting());
		Thread.sleep(1000);
		homePage.generalSetting().click();
		Thread.sleep(1000);
		reportHelper.generateLogFullScreenSS(test, "General setting page");

	}

	public void statusMaster() throws InterruptedException, IOException {

		genericHelper.scrollingTillWebElement(homePage.master());

		//	genericHelper.clickWithjavascriptExecutor(homePage.setting());

		homePage.master().click(); 
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.statusMaster());
		Thread.sleep(1000);
		homePage.statusMaster().click();
		Thread.sleep(1000);
		reportHelper.generateLogFullScreenSS(test, "Status master  page");

	}

	public void approvalSettingsPage() throws InterruptedException
	{
		try {

			homePage.billCheckingTransaction().click();
			Thread.sleep(1000); 

		} catch (Exception e) {
			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
			Thread.sleep(1000); 

			homePage.billCheckingMaster().click();
			Thread.sleep(1000); 

			genericHelper.scrollingTillWebElement(homePage.approvalSettings());
			Thread.sleep(1000);
			homePage.approvalSettings().click();
			Thread.sleep(1000); 
		}
	}

	public void billCheckingTransactionPage() throws InterruptedException
	{
		if(homePage.billCheckingTransaction().isDisplayed()) {

			homePage.billCheckingTransaction().click();
			Thread.sleep(1000); 

		} else {
			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
			Thread.sleep(1000); 

			homePage.billCheckingMaster().click();
			Thread.sleep(1000); 

			genericHelper.scrollingTillWebElement(homePage.approvalSettings());
			Thread.sleep(1000);
			homePage.billCheckingTransaction().click();
			Thread.sleep(1000); 
		}
	}

	public void billPaymentsPage() throws InterruptedException
	{
		if(homePage.billPayment().isDisplayed()) {

			homePage.billPayment().click();
			Thread.sleep(1000); 

		} else
		{

			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
			Thread.sleep(1000); 

			homePage.billCheckingMaster().click();
			Thread.sleep(1000); 

			genericHelper.scrollingTillWebElement(homePage.approvalSettings());
			Thread.sleep(1000);
			homePage.billPayment().click();
			Thread.sleep(1000);
		}
	} 

	public void payemntTemplateMasterPage() throws InterruptedException
	{

		try  
		{ 
			homePage.paymentTemplateMaster().click();		

		} catch (Exception e) {
			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
			Thread.sleep(1000);
			genericHelper.clickWithjavascriptExecutor(homePage.billCheckingMaster());
			Thread.sleep(1000);
			genericHelper.scrollingTillWebElement(homePage.paymentTemplateMaster());
			Thread.sleep(1000);

			//			homePage.master().click(); 
			//			Thread.sleep(1000);

			homePage.paymentTemplateMaster().click();					
		} 
	}

	public void vendorMasterPage() throws InterruptedException
	{

		try  
		{
			homePage.vendorMaster().click();		

		} catch (Exception e) {
			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());

			genericHelper.clickWithjavascriptExecutor(homePage.billCheckingMaster());

			genericHelper.scrollingTillWebElement(homePage.vendorMaster());


			//			homePage.master().click(); 
			//			Thread.sleep(1000);

			homePage.vendorMaster().click();					
		}
		//		if(homePage.vendorMaster().isDisplayed()) {
		//
		//			homePage.vendorMaster().click();			
		// 
		//		} else {
		//
		//			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
		//
		//			genericHelper.clickWithjavascriptExecutor(homePage.billCheckingMaster());
		//
		//			genericHelper.scrollingTillWebElement(homePage.vendorMaster());
		//
		//			
		////			homePage.master().click(); 
		////			Thread.sleep(1000);
		//
		//			homePage.vendorMaster().click();			
	}	

	//		if(homePage.vendorMaster().isDisplayed())
	//		{	
	//			homePage.vendorMaster().click(); 
	//			Thread.sleep(1000); 
	//
	//		}
	//		else {
	// 
	//
	//			genericHelper.scrollingTillWebElement(homePage.billCheckingMaster());
	//
	//			genericHelper.clickWithjavascriptExecutor(homePage.billCheckingMaster());
	//
	//			javascriptExecutor.executeScript("arguments[0].scrollIntoView();", homePage.vendorMaster());
	//			Thread.sleep(1000);
	//			homePage.vendorMaster().click(); 
	//			Thread.sleep(1000); 
	//		}


	public void cityMasterPage() throws InterruptedException
	{
		//		if(!visitMaster)
		//		{
		genericHelper.scrollingTillWebElement(homePage.master());

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.cityMaster());
		Thread.sleep(500);
		homePage.cityMaster().click();
		Thread.sleep(500);	

		//			visitMaster = true;
		//		}
		// 
		//		else {
		//			genericHelper.scrollingTillWebElement(homePage.cityMaster());
		// 
		// 
		//			homePage.cityMaster().click();
		//			//Thread.sleep(1000);  
		// 
		//	}

	}


	public void queryTypeMasterPage() throws InterruptedException
	{
		//		if(!visitMaster)
		//		{
		genericHelper.scrollingTillWebElement(homePage.master());

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.queryTypeMaster());
		Thread.sleep(500);
		homePage.queryTypeMaster().click();
		Thread.sleep(500);	

		//			visitMaster = true;
		//		}
		// 
		//		else {
		//			genericHelper.scrollingTillWebElement(homePage.cityMaster());
		// 
		// 
		//			homePage.cityMaster().click();
		//			//Thread.sleep(1000);  
		// 
		//	}

	}


	public void queryGroupMasterPage() throws InterruptedException, IOException
	{
		//		if(!visitMaster)
		//		{
		genericHelper.scrollingTillWebElement(homePage.master());

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.queryTypeMaster());
		Thread.sleep(500);
		homePage.queryTypeMaster().click();
		Thread.sleep(500);	

		reportHelper.generateLogWithScreenshot(test, "Query type master page");
		Thread.sleep(500);	


		//queryGroupMasterPage.addBtn().click();



	}



	public void projectMasterPage() throws InterruptedException
	{

		genericHelper.scrollingTillWebElement(homePage.projectManagement());

		//genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(500);

		homePage.projectManagement().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.projectMaster());
		Thread.sleep(500);
		homePage.projectMaster().click();
		Thread.sleep(500);	


		/*if(homePage.projectMaster().isDisplayed()) {

			homePage.projectMaster().click();			

		} else {

			homePage.master().click();
			Thread.sleep(1000);

			homePage.projectMaster().click();			
		}*/	

	}

	public void stateMasterPage() throws InterruptedException
	{
		//		if(homePage.stateMaster().isDisplayed())
		//		{	
		//			homePage.stateMaster().click(); 
		//			Thread.sleep(1000); 
		//
		//		}
		//		else {


		genericHelper.scrollingTillWebElement(homePage.master());

		//	genericHelper.clickWithjavascriptExecutor(homePage.master());

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.stateMaster());
		Thread.sleep(1000);
		homePage.stateMaster().click(); 
		Thread.sleep(1000); 
		//}

	}

	public void customerMappingPage() throws InterruptedException, IOException {

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(1000);

		homePage.master().click();
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.customerMapping());
		Thread.sleep(1000);
		homePage.customerMapping().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Customer mapping page");
	}


	public void departmentMasterPage() throws InterruptedException {
		if(homePage.departmentMaster().isDisplayed()) {
			homePage.departmentMaster().click();
			Thread.sleep(2000);
		}
		else
		{
			genericHelper.scrollingTillWebElement(homePage.master());
			Thread.sleep(1000);

			homePage.master().click();
			Thread.sleep(1000);

			genericHelper.scrollingTillWebElement(homePage.departmentMaster());
			Thread.sleep(1000);
			homePage.departmentMaster().click();
			Thread.sleep(1000);
		}
	}

	public void userMasterPage() throws InterruptedException {
		if(homePage.userMaster().isDisplayed()) {
			homePage.userMaster().click();
			Thread.sleep(2000);
		}
		else
		{
			genericHelper.scrollingTillWebElement(homePage.master());
			Thread.sleep(1000);

			homePage.master().click();
			Thread.sleep(1000);

			genericHelper.scrollingTillWebElement(homePage.userMaster());
			Thread.sleep(1000);
			homePage.userMaster().click();
			Thread.sleep(1000);
		}
	}



	public void roleMasterPage() throws InterruptedException {
		if(homePage.roleMaster().isDisplayed()) {
			homePage.roleMaster().click();
			Thread.sleep(2000);
		}
		else
		{
			genericHelper.scrollingTillWebElement(homePage.master());
			Thread.sleep(1000);

			homePage.master().click();
			Thread.sleep(1000);

			genericHelper.scrollingTillWebElement(homePage.roleMaster());
			Thread.sleep(1000);
			homePage.roleMaster().click();
			Thread.sleep(1000);
		}
	}

	public void countryMasterPage() throws InterruptedException, IOException
	{
		genericHelper.scrollingTillWebElement(homePage.master());

		//	genericHelper.clickWithjavascriptExecutor(homePage.master());

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.countryMaster());
		Thread.sleep(1000);
		homePage.countryMaster().click(); 
		Thread.sleep(1000); 

		reportHelper.generateLogFullScreenSS(test, "Country master page");
	}

	public void rollMasterPage() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(1000);

		homePage.master().click();
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.roleMaster());
		Thread.sleep(1000);
		homePage.roleMaster().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Role master page");
	}

	public void moduleMasterPage() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(1000);

		homePage.projectManagement().click();
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.moduleMaster());
		Thread.sleep(1000);
		homePage.moduleMaster().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Module master page");
	}

	public void subModuleMasterPage() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(1000);

		homePage.projectManagement().click();
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.subModuleMaster());
		Thread.sleep(1000);
		homePage.subModuleMaster().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Sub module master page");
	}

	public void dynamicFormPage() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(1000);

		homePage.master().click(); 
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.dynamicForm());
		Thread.sleep(1000);
		homePage.dynamicForm().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Dynamic form page");
	}

	public void dynamicFormDropdown() throws InterruptedException, IOException
	{

		genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(1000);

		homePage.master().click(); 
		Thread.sleep(1000);

		genericHelper.scrollingTillWebElement(homePage.dynamicFormDropdown());
		Thread.sleep(1000);
		homePage.dynamicFormDropdown().click();
		Thread.sleep(1000);

		reportHelper.generateLogFullScreenSS(test, "Dynamic form page");
	}

	public void customerMasterPage() throws InterruptedException
	{

		genericHelper.scrollingTillWebElement(homePage.master());

		//genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.customerMaster());
		Thread.sleep(500);
		homePage.customerMaster().click();
		Thread.sleep(500);	

		//		if(homePage.customerMaster().isDisplayed()) {
		//
		//			homePage.customerMaster().click();			
		//
		//		} else { 
		//
		//			homePage.master().click(); 
		//			Thread.sleep(1000);
		//
		//			homePage.customerMaster().click();			
		//		}	
	}

	public void departmentMaster() throws InterruptedException {

		genericHelper.scrollingTillWebElement(homePage.master());

		//genericHelper.scrollingTillWebElement(homePage.master());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.departmentMaster());
		Thread.sleep(500);
		homePage.departmentMaster().click();
		Thread.sleep(500);	


	}

	public void designationMaster() throws InterruptedException {

		genericHelper.scrollingTillWebElement(homePage.master());

		//genericHelper.scrollingTillWebElement(homePage.projectManagement());
		Thread.sleep(500);

		homePage.master().click();
		Thread.sleep(500);

		genericHelper.scrollingTillWebElement(homePage.designationMaster());
		Thread.sleep(500);
		homePage.designationMaster().click();
		Thread.sleep(500);	


	}

}
