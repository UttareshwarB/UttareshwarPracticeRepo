package com.ts.pagelayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.ts.utils.MasterClass;
import java.time.Duration;

public class CountryMasterPage extends MasterClass {

	private WebDriverWait wait;

	public CountryMasterPage() {
		PageFactory.initElements(driver, this);
		wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Default timeout of 10 seconds
	}

	private WebElement waitForElement(WebElement element) {
		return wait.until(ExpectedConditions.visibilityOf(element));
	}

	@FindBy(xpath = "//button[text()='Add Country']")
	private WebElement addCountry;

	public WebElement addCountry() {
		return waitForElement(addCountry);
	}

	@FindBy(id = "country")
	private WebElement country;

	public WebElement country() {
		return waitForElement(country);
	}

	@FindBy(name = "remark")
	private WebElement remark;

	public WebElement remark() {
		return waitForElement(remark);
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[1]/div/button")
	private WebElement editBtn;

	public WebElement editBtn() {
		return waitForElement(editBtn);
	}

	@FindBy(xpath = "//button[text()='Update']")
	private WebElement updateBtn;

	public WebElement updateBtn() {
		return waitForElement(updateBtn);
	}

	@FindBy(xpath = "//button[text()='Cancel']")
	private WebElement cancelBtn;

	public WebElement cancelBtn() {
		return waitForElement(cancelBtn);
	}

	@FindBy(xpath = "//input[@id='is_active_0']")
	private WebElement deactiveStatus;

	public WebElement deactiveStatus() {
		return waitForElement(deactiveStatus);
	}

	@FindBy(xpath = "//input[@id='is_active_1']")
	private WebElement activeStatus;

	public WebElement activeStatus() {
		return waitForElement(activeStatus);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[3]/div")
	private WebElement viewCountry;

	public WebElement viewCountry() {
		return waitForElement(viewCountry);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[4]/div")
	private WebElement viewStatus;

	public WebElement viewStatus() {
		return waitForElement(viewStatus);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[6]/div")
	private WebElement viewCreatedBy;

	public WebElement viewCreatedBy() {
		return waitForElement(viewCreatedBy);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[5]/div")
	private WebElement viewCreatedAt;

	public WebElement viewCreatedAt() {
		return waitForElement(viewCreatedAt);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[8]/div")
	private WebElement viewUpdatedBy;

	public WebElement viewUpdatedBy() {
		return waitForElement(viewUpdatedBy);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[7]/div")
	private WebElement viewUpdatedAt;

	public WebElement viewUpdatedAt() {
		return waitForElement(viewUpdatedAt);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[1]//button")
	private WebElement viewAction;

	public WebElement viewAction() {
		return waitForElement(viewAction);
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[2]/div")
	private WebElement viewSrno;

	public WebElement viewSrno() {
		return waitForElement(viewSrno);
	}

	@FindBy(xpath = "//button[text()='Add']")
	private WebElement addButton;

	public WebElement addButton() {
		return waitForElement(addButton);
	}

	@FindBy(xpath = "//button[text()='Cancel']")
	private WebElement cancelButton;

	public WebElement cancelButton() {
		return waitForElement(cancelButton);
	}
}
