package com.ts.pagelayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ts.utils.MasterClass;

public class HomePage extends MasterClass {

	// public static HomePage singleton = new HomePage( );
	//
	// /* A private Constructor prevents any other
	// * class from instantiating.
	// */
	// private HomePage() { }
	//
	// /* Static 'instance' method */
	// public static HomePage getInstance( ) {
	// return singleton;
	// }

	public HomePage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//span[text()='Ticket Management']")
	private WebElement ticketManagement;

	public WebElement ticketManagement() {
		return ticketManagement;
	}

	@FindBy(xpath = "//span[text()='My Tickets']")
	private WebElement myTickets;

	public WebElement myTickets() {
		return myTickets;
	}

	// span[text()='Ticket']
	@FindBy(xpath = "//span[text()='Ticket']")
	private WebElement tickets;

	public WebElement tickets() {
		return tickets;
	}

	@FindBy(xpath = "//*[text()='Create Ticket']")
	private WebElement createTicket;

	public WebElement createTicket() {
		return createTicket;
	}

	@FindBy(xpath = "//span[text()='Reports']")
	private WebElement reports;

	public WebElement reports() {
		return reports;
	}

	@FindBy(xpath = "//a[@href='/TechTicket/Report/ResourcePlanningReport']")
	private WebElement resourcePlanningReport;

	public WebElement resourcePlanningReport() {
		return resourcePlanningReport;
	}

	@FindBy(xpath = "//span[text()='Dashboard']")
	private WebElement dashboard;

	public WebElement dashboard() {
		return dashboard;
	}

	// span[text()='Bill Checking Master']
	// @FindBy (xpath = "//span[text()='Bill Checking']")
	@FindBy(xpath = "//span[contains(text(),'Bill Checking')]")
	private WebElement billCheckingMaster;

	public WebElement billCheckingMaster() {
		return billCheckingMaster;
	}

	// a[@href='/TechTicketDummy/vendorMaster']
	/// html/body/div/div/div[1]/div/ul[1]/li[10]/ul/li[1]/a/span
	@FindBy(xpath = "//*[text()='Vendor Master']")
	private WebElement vendorMaster;

	public WebElement vendorMaster() {
		return vendorMaster;
	}

	@FindBy(xpath = "//span[text()='Bill Checking Transaction']")
	private WebElement billCheckingTransaction;

	public WebElement billCheckingTransaction() {
		return billCheckingTransaction;
	}

	// span[text()='Master']
	@FindBy(xpath = "//span[text()='Master']")
	private WebElement master;

	public WebElement master() {
		return master;
	}

	@FindBy(xpath = "//a[text()='Designation Master']")
	private WebElement designationMaster;

	public WebElement designationMaster() {
		// TODO Auto-generated method stub
		return designationMaster;
	}

	@FindBy(xpath = "//a[text()='Department Master']")
	private WebElement departmentMaster;

	public WebElement departmentMaster() {
		return departmentMaster;
	}

	@FindBy(xpath = "//a[text()='Customer Type Master']")
	private WebElement CustomerTypeMaster;

	public WebElement customerTypeMaster() {
		return CustomerTypeMaster;
	}

	@FindBy(xpath = "//*[text()='Settings']")
	private WebElement setting;

	public WebElement setting() {
		return setting;
	}

	@FindBy(xpath = "//*[text()='Dynamic Form']")
	private WebElement dynamicForm;

	public WebElement dynamicForm() {
		return dynamicForm;
	}

	@FindBy(xpath = "//*[text()='Dynamic Form Dropdown']")
	private WebElement dynamicFormDropdown;

	public WebElement dynamicFormDropdown() {
		return dynamicFormDropdown;
	}

	// span[text()='Master']
	// @FindBy (xpath = "//span[text()='Master']")
	// private WebElement projectManagement;
	//
	// public WebElement master()
	// {
	// return master;
	// }

	@FindBy(xpath = "//a[text()='State Master']")
	private WebElement stateMaster;

	public WebElement stateMaster() {
		return stateMaster;
	}

	@FindBy(xpath = "//a[text()='City Master']")
	private WebElement cityMaster;

	public WebElement cityMaster() {
		return cityMaster;
	}

	@FindBy(xpath = "//a[text()='General Settings']")
	private WebElement generalSetting;

	public WebElement generalSetting() {
		return generalSetting;
	}

	@FindBy(xpath = "//*[text()='Status Master']")
	private WebElement statusMaster;

	public WebElement statusMaster() {
		return statusMaster;
	}

	@FindBy(xpath = "//a[text()='QueryType Master']")
	private WebElement queryTypeMaster;

	public WebElement queryTypeMaster() {
		return queryTypeMaster;
	}

	@FindBy(xpath = "//span[text()='Project Management']")
	private WebElement projectManagement;

	public WebElement projectManagement() {

		return projectManagement;
	}

	@FindBy(xpath = "//a[text()='Project Master']")
	private WebElement projectMaster;

	public WebElement projectMaster() {
		return projectMaster;
	}

	@FindBy(xpath = "//*[text()='Consolidated View']")
	private WebElement consolidatedView;

	public WebElement consolidatedView() {
		return consolidatedView;
	}

	// span[text()='Master']
	@FindBy(xpath = "//span[text()='User Master']")
	private WebElement userMaster;

	public WebElement userMaster() {
		return userMaster;
	}

	@FindBy(xpath = "//button[text()='Unpassed Ticket']")
	private WebElement unpassedTicket;

	public WebElement unpassedTicket() {
		return unpassedTicket;
	}

	@FindBy(xpath = "//div[@class='notifications dropdown']")
	private WebElement notificationBtn;

	public WebElement notificationBtn() {
		return notificationBtn;
	}

	@FindBy(xpath = "//span[text()='Approval Settings']")
	private WebElement approvalSettings;

	public WebElement approvalSettings() {
		return approvalSettings;
	}

	//// i[contains(text(),'Bill Type Master')]
	@FindBy(xpath = "//span[text()='Bill Type Master']")
	private WebElement billTypeMaster;

	public WebElement billTypeMaster() {
		return billTypeMaster;
	}

	@FindBy(xpath = "//span[text()='Bill Payments']")
	private WebElement billPayment;

	public WebElement billPayment() {
		return billPayment;
	}

	@FindBy(xpath = "//*[text()='Payment Template Master']")
	private WebElement paymentTemplateMaster;

	public WebElement paymentTemplateMaster() {
		return paymentTemplateMaster;
	}

	@FindBy(xpath = "//a[text()=' Assigned Person']")
	private WebElement assignedPersonAction;

	public WebElement assignedPersonAction() {
		return assignedPersonAction;
	}

	@FindBy(xpath = "//a[contains(text(),' View')]")
	private WebElement viewAction;

	public WebElement viewAction() {
		return viewAction;
	}

	// /@FindBy (xpath = "//span[text()='Country Master']")
	@FindBy(xpath = "//a[text()='Country Master']")
	private WebElement countryMaster;

	public WebElement countryMaster() {
		return countryMaster;
	}

	@FindBy(xpath = "//a[text()='Customer Mapping']")
	private WebElement customerMapping;

	public WebElement customerMapping() {
		return customerMapping;
	}

//	@FindBy (xpath = "//a[text()='Department Master']")
//	private WebElement departmentMaster;
//
//	public WebElement departmentMaster()
//	{
//		return departmentMaster;
//	}

	@FindBy(xpath = "//a[text()='Role Master']")
	private WebElement roleMaster;

	public WebElement roleMaster() {
		return roleMaster;
	}

	@FindBy(xpath = "//a[text()='Module Master']")
	private WebElement moduleMaster;

	public WebElement moduleMaster() {
		return moduleMaster;
	}

	@FindBy(xpath = "//a[text()='Submodule Master']")
	private WebElement subModuleMaster;

	public WebElement subModuleMaster() {
		return subModuleMaster;
	}

	//
	@FindBy(xpath = "//a[text()='Customer Master']")
	private WebElement customerMaster;

	public WebElement customerMaster() {
		return customerMaster;
	}
}
