package com.ts.pagelayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ts.utils.MasterClass;

public class ModuleMasterPage extends MasterClass {

	public ModuleMasterPage()
	{
		PageFactory.initElements(driver, this);
	}

	//@FindBy(xpath="//button[@class='btn btn-dark btn-set-task w-sm-100']")
	@FindBy(xpath="//a[text()='Add Module']")
	private WebElement addModule;

	public WebElement addModule()
	{
		return addModule;  
	}


	@FindBy(xpath="//select[@id='project_id']")
	private WebElement selectProject;

	public WebElement selectProject()
	{
		return selectProject;
	}

	@FindBy(xpath="//input[@id='module_name']")
	private WebElement selectModuleName;

	public WebElement selectModuleName()
	{
		return selectModuleName;
	}
	
	@FindBy(xpath="//input[@name='module_name']")
	private WebElement editSelectModuleName;

	public WebElement editSelectModuleName()
	{
		return editSelectModuleName;
	}



	@FindBy(xpath="//textarea[@id='description']")
	private WebElement description;

	public WebElement description()
	{
		return description;
	}
	
	@FindBy(xpath="//textarea[@name='description']")
	private WebElement editDescription;

	public WebElement editDescription()
	{
		return editDescription;
	}


	@FindBy(xpath="//input[@id='remark']")
	private WebElement remark;

	public WebElement remark()
	{
		return remark;
	}
	
	@FindBy(xpath="//input[@name='remark']")
	private WebElement editRemark;

	public WebElement editRemark()
	{
		return editRemark;
	}

	@FindBy(xpath = "//button[text()='Submit']")
	private WebElement submitBtn;

	public WebElement submitBtn()
	{
		return submitBtn;
	}

	@FindBy(xpath="//a[text()='Cancel']")
	private WebElement cancelBtn;

	public WebElement cancelBtn()
	{
		return cancelBtn;
	}


	@FindBy(xpath="//input[@type='search']")
	private WebElement search;

	public WebElement search()
	{
		return search;
	}

	@FindBy(xpath="//button[text()=' Search']")
	private WebElement searchBtn;

	public WebElement searchBtn()
	{
		return searchBtn;
	}


	//@FindBy(xpath="(//div[contains(@class,'TableRow')])[1]/div[1]/div/a/i")
	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div//a")
	private WebElement editBtn;

	public WebElement editBtn()
	{
		return editBtn;
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]")
	private WebElement gridFirstRow;

	public WebElement gridFirstRow()
	{
		return gridFirstRow;
	}


	@FindBy(xpath="//button[text()='Update']")
	private WebElement updateBtn;

	public WebElement updateBtn()
	{
		return updateBtn;
	}

	//@FindBy(xpath="//input[@id='is_active_0']")
	@FindBy(xpath = "//input[@value='0']")
	private WebElement deactiveStatus;

	public WebElement deactiveStatus()
	{
		return deactiveStatus;
	}

	//@FindBy(xpath="//input[@id='is_active_1']")
	@FindBy(xpath = "//input[@value='1']")
	private WebElement activeStatus;

	public WebElement activeStatus()
	{
		return activeStatus;
	}

	//div[contains(@class,'TableRow')])[1]/div[2]/div
	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[2]/div")
	private WebElement SrNo;

	public WebElement SrNo()
	{
		return SrNo;
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[3]/div")
	private WebElement viewModule;

	public WebElement viewModule()
	{
		return viewModule;
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[4]/div")
	private WebElement viewProject;

	public WebElement viewProject()
	{
		return viewProject;
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[5]/div")
	private WebElement viewStatus;

	public WebElement viewStatus()
	{
		return viewStatus;
	}

	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[6]/div")
	private WebElement viewDescription;

	public WebElement viewDescription()
	{
		return viewDescription;
	}
	
	@FindBy(xpath = "(//div[contains(@class,'TableRow')])[1]/div[7]/div")
	private WebElement viewRemark;

	public WebElement viewRemark()
	{
		return viewRemark;
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[2]/div")
	private WebElement viewSrno;

	public WebElement viewSrno()
	{
		return viewSrno;
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[9]/div")
	private WebElement viewCreatedAt;

	public WebElement viewCreatedAt()
	{
		return viewCreatedAt;
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[8]/div")
	private WebElement viewCreatedBy;

	public WebElement viewCreatedBy()
	{
		return viewCreatedBy;
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[10]/div")
	private WebElement viewUpdatedBy;

	public WebElement viewUpdatedBy()
	{
		return viewUpdatedBy;
	}

	@FindBy(xpath = "//div[contains(@class,'TableBody')]/div[1]//div[11]/div")
	private WebElement viewUpdatedAt;

	public WebElement viewUpdatedAt()
	{
		return viewUpdatedAt;
	}

}


