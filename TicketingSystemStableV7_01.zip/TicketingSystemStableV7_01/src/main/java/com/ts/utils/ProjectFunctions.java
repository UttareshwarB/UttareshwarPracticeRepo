package com.ts.utils;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.sharedutils.ExcelHelper;
import com.sharedutils.GenericHelper;
import com.sharedutils.GlobalConstants;
import com.sharedutils.MasterDto;
import com.sharedutils.PropertyHelper;
import com.sharedutils.ReportsHelper;
import com.sharedutils.ScreenShotHelper;
import com.ts.core.*;
import com.ts.pagelayer.*;

public class ProjectFunctions implements ProjectConstants {

	public GenericHelper genericHelper = new GenericHelper();
	public ExcelHelper excelHelper = new ExcelHelper();
	public PropertyHelper propertyHelper = new PropertyHelper();
	public ReportsHelper reportHelper = new ReportsHelper();
	public ScreenShotHelper ssHelper = new ScreenShotHelper();
	public static MasterDto masterDto = new MasterDto();

	public static ExtentReports extentReports;
	public static ExtentTest test;
	public static WebDriver driver;
	public static XSSFSheet sheet;
	public SoftAssert softAssert = new SoftAssert();

	protected static boolean isLoggedIn = false;
	protected JavascriptExecutor js = (JavascriptExecutor) driver;

	// public static CountryMasterPage countryMasterPage;

	// username
	protected static String username;

	// full Name
	protected static String createdBy;
	protected static String updatedBy;
	public static String loggedInUserName;
	protected String sysTimeDate;

	protected static String createdByDateTime;
	protected static String updatedByDateTime;

	protected static String tostifyMessage;
	protected static String errorMessage;
	protected static String tooltipMessage;

	// Pom Page
	public static LoginPage loginPage;
	public static CountryMasterPage countryMasterPage;

	public static HomePage homePage;
	public static CommonFields commonFields;
	public static NavigateToPage navigateToPage;

	// public static DepartmentMasterPage departmentMasterPage;

	public static ModuleMasterPage moduleMasterPage;

	public static DepartmentMasterPage departmentMasterPage;

	// Core Pages
	public static CountryMaster countryMaster;


	// public static DepartmentMaster departmentMaster;

	public static DepartmentMaster departmentMaster;

	// Other
	public static JavascriptExecutor javascriptExecutor;
	public static WebDriverWait wait;
	public static WebDriverWait shortWait;
	public static WebDriverWait mediumWait;

	public void pageInitialiazation(WebDriver driver) {
		loginPage = new LoginPage();
		// Pom Pages
		homePage = new HomePage();
		commonFields = new CommonFields();

		countryMasterPage = new CountryMasterPage();
		navigateToPage = new NavigateToPage();
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		shortWait = new WebDriverWait(driver, Duration.ofSeconds(10));
		mediumWait = new WebDriverWait(driver, Duration.ofSeconds(30));


		departmentMasterPage = new DepartmentMasterPage();

		moduleMasterPage = new ModuleMasterPage();

		// Core pages
		countryMaster = new CountryMaster();

		// departmentMaster = new DepartmentMaster();

		departmentMaster = new DepartmentMaster();

	}

	public void login() throws InterruptedException, Exception {
		// Fetch the username and password from config.properties
		String uname = propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE, "Uname");
		String pwd = propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE, "pwd");

		// Set the global username variable if needed
		username = uname;

		// Only perform login if not already logged in
		if (!isLoggedIn) {
			// Enter credentials using the generic helper method
			genericHelper.insertDataIntoField(loginPage.username(), uname);
			genericHelper.insertDataIntoField(loginPage.password(), pwd);

			// A brief pause for stability before clicking sign in
			Thread.sleep(500);
			loginPage.signinBtn().click();

			try {
				// If a toast message is displayed (e.g. an error), capture it and log failure
				if (commonFields.toastifyMsg().isDisplayed()) {
					String msg = driver
							.findElement(By.xpath("//div[@class='Toastify__toast-body' and @role='alert']/div"))
							.getText();
					test.fail(msg);
					test.fail("<b>User Name : " + uname + "<br />Password : " + pwd + "<b/>");
					reportHelper.generateLog(test, "Login error occurred");
				}
			} catch (Exception e) {
				// If no toast message is detected, assume login succeeded and wait for the
				// logged-in user name element
				Thread.sleep(3000);
				loggedInUserName = driver
						.findElement(By.xpath("//div[@class='notifications dropdown']/following-sibling::div/p"))
						.getText();
				test.pass("<b>User Name : " + uname + "<br />Password : " + pwd + "<b/>");
				test.pass("<b>Full user Name : " + loggedInUserName + "</b>");
				reportHelper.onTestSuccess(test, "Login successful");
				isLoggedIn = true;
			}
		}
	}

	// public void loginPage(WebDriver driver) throws InterruptedException,
	// Exception, IOException
	//
	// {
	// WebElement username = driver.findElement(By.id("email_id"));
	//
	// username.clear();
	// Thread.sleep(1000);
	//
	// username.sendKeys(propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE,
	// "Uname"));
	// Thread.sleep(2500);
	//
	// WebElement pwd = driver.findElement(By.id("password"));
	// pwd.clear();
	// Thread.sleep(1000);
	//
	// pwd.sendKeys(propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE,
	// "pwd"));
	// Thread.sleep(2500);
	//
	// test.info("<b>Uname : " +
	// propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE, "Uname")
	// + "<br />Password : " +
	// propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE, "pwd")
	// + "<b/>");
	//
	// driver.findElement(By.xpath("//button[text()='SIGN IN']")).click();
	// Thread.sleep(3000);
	//
	// reportHelper.onTestSuccess(test, "<b>Logged in successfully<b/>");
	// }

	public void logoutPage(WebDriver driver) throws InterruptedException, Exception {
		WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(50));
		JavascriptExecutor js = (JavascriptExecutor) driver;

		w.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("(//img[@alt='profile'])[1]"))));
		Thread.sleep(2500);

		js.executeScript("window.scrollTo(0, -document.body.scrollHeight)");

		driver.findElement(By.xpath("(//img[@alt='profile'])[1]")).click();
		Thread.sleep(2500);

		driver.findElement(By.xpath("//span[text()='Sign Out']")).click();
		Thread.sleep(2500);

		reportHelper.onTestSuccess(test, "<b>Logged Out successfully<b/>");
	}

	public void handleDropdown(String data, WebElement element) throws InterruptedException {
		if (data != null) {
			String[] data1 = data.split(",");

			genericHelper.actions.click(element);

			for (String data2 : data1) {
				System.out.println(data2);

				genericHelper.actions.sendKeys(data2.trim()).pause(20).sendKeys(Keys.ENTER).build().perform();

				Thread.sleep(1000);

			}
		}
	}

	public void saveAndUpdateAction(ExtentTest test, WebElement saveBtn, WebElement cancelBtn, String expectedOutput)
			throws IOException, InterruptedException {
		try {
			// Assert.assertTrue(saveBtn.isEnabled());
			saveBtn.click();

			Thread.sleep(500);
			String msg = commonFields.toastifyMsg().getText();
			tostifyMessage = msg;
			Thread.sleep(500);

			System.out.println("Toast msg : " + msg + " expected output : " + expectedOutput);

			if (commonFields.toastifyMsg().isDisplayed() && msg.toLowerCase().contains(expectedOutput.toLowerCase())) {
				reportHelper.onTestSuccess(test, msg);
				reportHelper.generateLogFullScreenSS(test, commonFields.toastifyMsg().getText());
				if (commonFields.toastifyCloseBtn().isDisplayed()) {
					commonFields.toastifyCloseBtn().click();
				}
			} else if (commonFields.toastifyMsg().isDisplayed()) {
				Thread.sleep(1500);
				// System.out.println("in loop :"+msg);
				// Thread.sleep(1500);

				reportHelper.onTestFailure(test, msg);
				Thread.sleep(1500);
				reportHelper.generateLogFullScreenSS(test, "Error");

				if (commonFields.toastifyCloseBtn().isDisplayed()) {
					commonFields.toastifyCloseBtn().click();
				}

			}
		} catch (Exception e) {
			if (cancelBtn.isDisplayed()) {
				reportHelper.onTestSuccess(test, "Test case pass : " + expectedOutput);
			} else {
				reportHelper.onTestFailure(test, "Test case fail : " + expectedOutput);
				reportHelper.generateLogFullScreenSS(test, "");

				genericHelper.clickWithjavascriptExecutor(cancelBtn);
			}
		}

		try {
			// if(cancelBtn.isDisplayed())
			// {
			cancelBtn.click();
			// Assert.assertTrue(false);
			// }
		} catch (Exception e) {
			reportHelper.generateLog(test, "Exception : " + e);
		}
	}

	public void saveAndUpdateActionUpdated(ExtentTest test, WebElement saveBtn, WebElement cancelBtn,
			String expectedOutput) throws IOException, InterruptedException {
		// Assert.assertTrue(saveBtn.isEnabled());
		saveBtn.click();

		Thread.sleep(1000);

		try {
			if (commonFields.toastifyMsg().isDisplayed()) {
				String msg = commonFields.toastifyMsg().getText();
				tostifyMessage = msg;
				Thread.sleep(500);

				System.out.println("Toast msg : " + msg + " expected output : " + expectedOutput);
				Thread.sleep(1000);
				commonFields.toastifyCloseBtn().click();
				Thread.sleep(500);
				if (msg.toLowerCase().contains(expectedOutput.toLowerCase())) {
					reportHelper.onTestSuccess(test, msg);
					reportHelper.generateLogFullScreenSS(test, commonFields.toastifyMsg().getText());
					// if (commonFields.toastifyCloseBtn().isDisplayed()) {
					// commonFields.toastifyCloseBtn().click();
					// }
				} else {
					Thread.sleep(1500);
					// System.out.println("in loop :"+msg);
					// Thread.sleep(1500);

					reportHelper.onTestFailure(test, msg);
					Thread.sleep(1500);
					reportHelper.generateLogFullScreenSS(test, "Error");

					// if(commonFields.toastifyCloseBtn().isDisplayed())
					// {
					// commonFields.toastifyCloseBtn().click();
					// }
				}
			}

			else if (cancelBtn.isDisplayed()) {
				reportHelper.onTestSuccess(test, "Test case pass : " + expectedOutput);
				genericHelper.clickWithjavascriptExecutor(cancelBtn);
			}

			else {
				reportHelper.onTestFailure(test, "Test case fail : " + expectedOutput);
				reportHelper.generateLogFullScreenSS(test, "");

				genericHelper.clickWithjavascriptExecutor(cancelBtn);
			}

			// else
			// {
			// // //genericHelper.clickWithjavascriptExecutor(cancelBtn);
			// // if (cancelBtn.isDisplayed()) {
			// // reportHelper.onTestSuccess(test, "Test case pass : "+expectedOutput);
			// // }
			// }
		}

		catch (Exception e) {
			reportHelper.generateLog(test, "Exception : " + e);
		}

		// else
		// {
		// reportHelper.onTestFailure(test, "Test case fail : "+expectedOutput);
		// reportHelper.generateLogFullScreenSS(test, "");
		//
		// genericHelper.clickWithjavascriptExecutor(cancelBtn);
		// }

		// catch (Exception e) {
		// if (cancelBtn.isDisplayed()) {
		// reportHelper.onTestSuccess(test, "Test case pass : "+expectedOutput);
		// }
		// else
		// {
		// reportHelper.onTestFailure(test, "Test case fail : "+expectedOutput);
		// reportHelper.generateLogFullScreenSS(test, "");
		//
		// genericHelper.clickWithjavascriptExecutor(cancelBtn);
		// }
		// }

		try {
			// if(cancelBtn.isDisplayed())
			// {
			cancelBtn.click();
			// Assert.assertTrue(false);
			// }
		} catch (Exception e) {
			reportHelper.generateLog(test, "Exception : " + e);
		}
	}

	public void saveAndUpdateActionUpdated3(ExtentTest test, WebElement saveBtn, WebElement cancelBtn,
			String expectedOutput) throws IOException, InterruptedException {
		tostifyMessage = null;
		errorMessage = null;
		tooltipMessage = null;
		WebElement toastElement = null;
		WebElement errorElement = null;
		// boolean cancelBtn2 = false;

		reportHelper.generateLogWithScreenshot(test, "Before save");

		Thread.sleep(2000);
		genericHelper.scrollingTillWebElement(saveBtn);

		genericHelper.clickWithjavascriptExecutor(saveBtn);

		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		sysTimeDate = timeFormat.format(now);
		try {

			try {
				// Check for Toastify message
				toastElement = mediumWait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));
				// toastElement =
				// wait.until(ExpectedConditions.visibilityOf(commonFields.toastifyMsg()));
				// tostifyMessage=toastElement.getText();

				tostifyMessage = getTemporaryElementMessage(toastElement);

				if (tostifyMessage != null) {
					System.out.println("Toastify message detecte : " + tostifyMessage);
				}
				// errorElement =
				// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
				// errorMessage= errorElement.getText();

				Thread.sleep(4000);

				// =cancelBtn.isDisplayed();

			} catch (Exception e) {

				reportHelper.onTestFailureLog(test, expectedOutput);
			}

			try {

				// tooltip
				if (tostifyMessage == null) {
					// JavascriptExecutor js = (JavascriptExecutor) driver;
					// String validationMessage = (String) js.executeScript(
					// "return arguments[0].validationMessage;", customerMasterPage.pincode());
					//
					// // Print the validation message
					// System.out.println("Validation message: " + validationMessage);

					// java.util.List<WebElement> inputFields =
					// driver.findElements(By.cssSelector("input, select, textarea"));
					java.util.List<WebElement> inputFields = driver
							.findElements(By.cssSelector("input, select, textarea"));

					JavascriptExecutor js = (JavascriptExecutor) driver;

					for (WebElement field : inputFields) {
						// Check if the field has a validation message
						String validationMessage = (String) js.executeScript("return arguments[0].validationMessage;",
								field);

						// Print validation message if present

						if (validationMessage != null && !validationMessage.isEmpty()) {
							reportHelper.performAssert(test, "Error message", expectedOutput, validationMessage);
							System.out.println("Validation message for field " + field.getAttribute("name") + ": "
									+ validationMessage);
							reportHelper.generateLog(test, "Validation message for field " + field.getAttribute("name")
									+ ": " + validationMessage);
						}
					}
				}

				// small tag
				if (tostifyMessage == null) {

					// errorElement =
					// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
					errorElement = shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("small")));
					errorMessage = errorElement.getText();

					if (errorMessage != null && !errorMessage.isEmpty()) {
						reportHelper.performAssert(test, "Error message", expectedOutput, errorMessage);
						System.out.println("Validation message " + errorMessage);
					}
				}
				if (tostifyMessage == null) {

					// errorElement =
					// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
					errorElement = shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("div")));
					errorMessage = errorElement.getText();

					if (errorMessage != null && !errorMessage.isEmpty()) {
						reportHelper.performAssert(test, "Error message", expectedOutput, errorMessage);
						System.out.println("Validation message " + errorMessage);
					}

				}

				if (tostifyMessage != null) {
					if (tostifyMessage.toLowerCase().contains(expectedOutput.toLowerCase())) {
						reportHelper.onTestSuccess(test, tostifyMessage);
						reportHelper.performAssert(test, "Record Status ", expectedOutput, tostifyMessage);
					} else {
						// reportHelper.onTestFailure(test, tostifyMessage +"Expected Output:- "+
						// expectedOutput);
						reportHelper.performAssert(test, "Output ", expectedOutput, tostifyMessage);
						reportHelper.generateLog(test, " Expected Output is different");

						reportHelper.generateLogWithScreenshot(test, tostifyMessage);
						// genericHelper.clickWithjavascriptExecutor(cancelBtn);
					}
				}

				else {
					reportHelper.onTestFailure(test, expectedOutput);
				}

			} catch (Exception e) {
				// TODO: handle exception
			} finally {
				driver.navigate().refresh();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public void saveAndUpdateActionUpdated4(ExtentTest test, WebElement saveBtn, String expectedOutput)
			throws IOException, InterruptedException {
		tostifyMessage = null;
		errorMessage = null;
		tooltipMessage = null;
		WebElement toastElement = null;
		WebElement errorElement = null;
		// boolean cancelBtn2 = false;

		reportHelper.generateLogWithScreenshot(test, "Before save");

		Thread.sleep(2000);
		genericHelper.scrollingTillWebElement(saveBtn);

		genericHelper.clickWithjavascriptExecutor(saveBtn);

		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		sysTimeDate = timeFormat.format(now);
		try {
			try {
				// Check for Toastify message
				toastElement = mediumWait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));
				// toastElement =
				// wait.until(ExpectedConditions.visibilityOf(commonFields.toastifyMsg()));
				// tostifyMessage=toastElement.getText();

				tostifyMessage = getTemporaryElementMessage(toastElement);

				if (tostifyMessage != null) {
					System.out.println("Toastify message detecte : " + tostifyMessage);
				}
				// errorElement =
				// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
				// errorMessage= errorElement.getText();

				Thread.sleep(4000);

				// =cancelBtn.isDisplayed();

			} catch (Exception e) {

				reportHelper.generateLog(test, expectedOutput);
			}

			try {
				if (tostifyMessage != null) {
					if (tostifyMessage.toLowerCase().contains(expectedOutput.toLowerCase())) {
						reportHelper.onTestSuccess(test, tostifyMessage);
						reportHelper.performAssert(test, "Record Status ", expectedOutput, tostifyMessage);
					} else {
						// reportHelper.onTestFailure(test, tostifyMessage +"Expected Output:- "+
						// expectedOutput);
						reportHelper.performAssert(test, "Output ", expectedOutput, tostifyMessage);
						reportHelper.generateLog(test, " Expected Output is different");

						reportHelper.generateLogWithScreenshot(test, tostifyMessage);
						// genericHelper.clickWithjavascriptExecutor(cancelBtn);
					}
				}

				else {
					reportHelper.onTestFailure(test, expectedOutput);
				}

			} catch (Exception e) {
				reportHelper.generateLogFullScreenSS(test, e.getMessage());
			}

			try {
				// tooltip
				if (tostifyMessage == null) {
					// JavascriptExecutor js = (JavascriptExecutor) driver;
					// String validationMessage = (String) js.executeScript(
					// "return arguments[0].validationMessage;", customerMasterPage.pincode());
					//
					// // Print the validation message
					// System.out.println("Validation message: " + validationMessage);

					// java.util.List<WebElement> inputFields =
					// driver.findElements(By.cssSelector("input, select, textarea"));
					java.util.List<WebElement> inputFields = driver.findElements(By.cssSelector("input"));

					JavascriptExecutor js = (JavascriptExecutor) driver;

					for (WebElement field : inputFields) {
						// Check if the field has a validation message
						String validationMessage = (String) js.executeScript("return arguments[0].validationMessage;",
								field);

						// Print validation message if present

						if (validationMessage != null && !validationMessage.isEmpty()) {
							reportHelper.performAssert(test, "Error message", expectedOutput, validationMessage);
							System.out.println("Validation message for field " + field.getAttribute("name") + ": "
									+ validationMessage);
							reportHelper.generateLog(test, "Validation message for field " + field.getAttribute("name")
									+ ": " + validationMessage);
						}
					}
				}
			} catch (Exception e) {
				reportHelper.generateLogFullScreenSS(test, e.getMessage());
			}

			try {
				// small tag
				if (tostifyMessage == null) {

					// errorElement =
					// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
					errorElement = shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("small")));
					errorMessage = errorElement.getText();

					if (errorMessage != null && !errorMessage.isEmpty()) {
						reportHelper.performAssert(test, "Error message", expectedOutput, errorMessage);
						System.out.println("Validation message " + errorMessage);
					}
				}
			} catch (Exception e) {
				reportHelper.generateLogFullScreenSS(test, e.getMessage());
			}

			// try
			// {
			// if(tostifyMessage==null)
			// {
			//
			// //errorElement =
			// wait.until(ExpectedConditions.visibilityOf(commonFields.errorMsg()));
			// errorElement =
			// shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("div")));
			// errorMessage= errorElement.getText();
			//
			// if (errorMessage != null && !errorMessage.isEmpty()) {
			// reportHelper.performAssert(test, "Error message", expectedOutput,
			// errorMessage);
			// System.out.println("Validation message " + errorMessage);
			// }
			//
			// }
			// }
			// catch (Exception e) {
			// reportHelper.generateLogFullScreenSS(test, e.getMessage());
			// }

			finally {
				driver.navigate().refresh();
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public String getTemporaryElementMessage(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return (String) js.executeScript("return arguments[0].textContent || arguments[0].innerText;", element);
	}

	public void saveAndUpdateActionUpdated2(ExtentTest test, WebElement saveBtn, WebElement cancelBtn,
			String expectedOutput) throws IOException, InterruptedException {
		// String msg=null;
		tostifyMessage = null;

		WebElement toastElement = null;

		reportHelper.generateLogWithScreenshot(test, "Before save data");

		System.out.println("In save and update");
		// JavascriptExecutor js1;

		Thread.sleep(2000);
		genericHelper.scrollingTillWebElement(saveBtn);
		// genericHelper.scrollingTillWebElement(saveBtn);

		genericHelper.clickWithjavascriptExecutor(saveBtn);
		// saveBtn.click();

		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		sysTimeDate = timeFormat.format(now);

		// Thread.sleep(1000);
		// try
		// {
		// toastElement =
		// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));
		// tostifyMessage= toastElement.getText();
		// ////////////
		// }
		// catch(Exception e)
		// {
		//
		// }

		try {
			toastElement = wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));

			if (commonFields.toastifyMsg().isDisplayed()) {
				// toastElement =
				// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));
				System.out.println("Tostify msg displayed bloack");
				tostifyMessage = toastElement.getText();
				Thread.sleep(1000);
				// String msg= commonFields.toastifyMsg().getText();
				// reportHelper.generateLogFullScreenSS(test, tostifyMessage);
				reportHelper.generateLogFullScreenSS(test, tostifyMessage);

				Thread.sleep(500);
				System.out.println("Toast msg : " + tostifyMessage + " expected output : " + expectedOutput);
				Thread.sleep(1000);

				// Thread.sleep(500);
				if (tostifyMessage.toLowerCase().contains(expectedOutput.toLowerCase())) {
					reportHelper.onTestSuccess(test, tostifyMessage);
					reportHelper.performAssert(test, "Record Status ", expectedOutput, tostifyMessage);

				} else {
					// reportHelper.onTestFailure(test, tostifyMessage +"Expected Output:- "+
					// expectedOutput);
					reportHelper.performAssert(test, "Output ", expectedOutput, tostifyMessage);
					reportHelper.generateLog(test, " Expected Output is different");

					reportHelper.generateLogWithScreenshot(test, tostifyMessage);
					genericHelper.clickWithjavascriptExecutor(cancelBtn);
				}
			} else if (isLoggedIn) {

				// /js = (JavascriptExecutor) driver;
				// String validationMessage = (String) js.executeScript(
				// "return arguments[0].validationMessage;", textField);
				//
				// // Print the validation message
				// System.out.println("Validation message: " + validationMessage);

			} else if (cancelBtn.isDisplayed()) {
				System.out.println("else if cancel block ");
				System.out.println("else block for Invalid data block ");
				reportHelper.generateLogFullScreenSS(test, "Toastify Message Not displayed");
				genericHelper.clickWithjavascriptExecutor(commonFields.backBtn());
				reportHelper.generateLogFullScreenSS(test, "Invalid data Entered in the form");
				Thread.sleep(2000);
				reportHelper.onTestFailure(test, expectedOutput);
				genericHelper.clickWithjavascriptExecutor(cancelBtn);

			}
			// reportHelper.generateLog(test, "Exception : "+e);
			// }
			else {
				System.out.println("Final else block");
				reportHelper.onTestFailure(test, "Test case fail : " + expectedOutput);
				reportHelper.generateLogFullScreenSS(test, "");
				genericHelper.clickWithjavascriptExecutor(cancelBtn);
			}
		} catch (Exception ee) {
			if (cancelBtn.isDisplayed()) {

				reportHelper.onTestFailure(test, "Test case fail : " + expectedOutput);
				reportHelper.generateLogFullScreenSS(test, "");
				genericHelper.clickWithjavascriptExecutor(cancelBtn);
			}
			reportHelper.generateLog(test, "Exception : " + ee);
		}

		finally {
			driver.navigate().refresh();
		}

	}

	public void statusSelection(WebElement activeStatus, WebElement deactiveStatus, String status) throws IOException {
		try {

			genericHelper.scrollingTillWebElement(activeStatus);

			if (status.equalsIgnoreCase("active")) {
				activeStatus.click();
			}

			else if (status.equalsIgnoreCase("deactive") || status.equalsIgnoreCase("inactive")) {
				deactiveStatus.click();
			}
		} catch (Exception e) {

			reportHelper.generateLog(test, "Unexpected error encountered: " + e.getMessage());
		}

	}

	public String getFullTextFromElement(WebElement element) throws IOException {
		// Get the visible text of the element

		// try {

		String visibleText = element.getText();

		// If the text contains '...', fetch the tooltip text
		if (visibleText.contains("...")) {
			return getTooltipText(element);
		}
		System.out.println("Tooltip Text: " + visibleText);

		// If no truncation, return the visible text
		return visibleText;

	}

	private String getTooltipText(WebElement element) {
		try {
			// Perform hover action
			genericHelper.actions.moveToElement(element).perform();

			// Wait briefly to allow tooltip to appear
			Thread.sleep(500);

			WebElement tooltip = driver.findElement(By.className("tooltip-inner"));

			String tooltipText = tooltip.getText();

			// genericHelper.actions.moveToElement(orangeBox).perform();
			//
			// // Wait for tooltip to appear
			// Thread.sleep(1000); // Adjust time based on your application's behavior
			//
			// // Locate the tooltip element
			// WebElement tooltip = driver.findElement(By.className("tooltip-inner"));
			//
			// // Get the tooltip text
			// String tooltipText = tooltip.getText();

			// Print the tooltip text
			System.out.println("Tooltip Text: " + tooltipText);

			// Use JavaScript to fetch the tooltip text
			// JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			// String tooltipText = (String) jsExecutor.executeScript(
			// "return arguments[0].getAttribute('aria-label') || " +
			// "arguments[0].getAttribute('title') || " +
			// "arguments[0].textContent;",
			// element
			// );

			return tooltipText != null ? tooltipText.trim() : "";
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	public void searchData(String search) throws InterruptedException, IOException {
		try {
			commonFields.resetBtn().click();

			genericHelper.insertDataIntoField(commonFields.search(), search);

			commonFields.searchBtn().click();

			reportHelper.generateLogWithScreenshot(test, "Search result");
		} catch (Exception e) {

			reportHelper.generateLog(test, "Unexpected error encountered: " + e.getMessage());
		}
	}

	// 31/7/2024

	public static boolean isFieldMandatory(WebElement element) {
		WebElement element1 = element;

		// Check if the 'required' attribute is present
		String requiredAttribute = element1.getAttribute("required");

		// If 'required' attribute is present, the field is mandatory
		return requiredAttribute != null && requiredAttribute.equals("true");
	}

	public static String getFieldMaxLength(WebElement element) {
		WebElement element1 = element;

		// Check if the 'maxlength' attribute is present
		String maxLengthAttribute = element1.getAttribute("maxlength");
		String defVal = "-1";
		// If 'maxlength' attribute is present, return the actual maximum length
		if (maxLengthAttribute != null) {
			try {
				return maxLengthAttribute;
			} catch (NumberFormatException e) {
				// Handle if the 'maxlength' attribute is not a valid integer

				return defVal;
			}
		}

		// If 'maxlength' attribute is not present, return -1
		return defVal;
	}

	public static String getFieldMinLength(WebElement element) {
		WebElement element1 = element;
		String defVal = "-1";

		// Check if the 'maxlength' attribute is present
		String maxLengthAttribute = element1.getAttribute("minlength");

		// If 'maxlength' attribute is present, return the actual maximum length
		if (maxLengthAttribute != null) {
			try {
				return maxLengthAttribute;
			} catch (NumberFormatException e) {
				// Handle if the 'maxlength' attribute is not a valid integer
				return defVal;
			}
		}

		// If 'maxlength' attribute is not present, return -1
		return defVal;
	}

	public void clearAndSendkeysWithActions(WebElement ele, String data) {
		genericHelper.actions.click(ele).keyDown(Keys.CONTROL).sendKeys("a") // Select all text
				.keyUp(Keys.CONTROL).pause(20).sendKeys(Keys.BACK_SPACE).pause(20) // Clear it
				.sendKeys(data).build().perform();
	}

	public void clearWithActions(WebElement ele) {
		genericHelper.actions.click(ele).keyDown(Keys.CONTROL).sendKeys("a") // Select all text
				.keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE) // Clear it
				.build().perform();
	}

	public void compareUserAndTimestamps(String actionAt, String actionBy, String msg) throws IOException {
		// DateTimeFormatter inputFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME; //
		// Handles "T"
		// DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd
		// HH:mm:ss");

		try {

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDateTime timeFoundSystem = LocalDateTime.parse(actionAt, formatter);

			// change sysTimeDate to format
			LocalDateTime createdTimeByCode = LocalDateTime.parse(sysTimeDate, formatter);

			// Compare sysTimeDate and grid time
			Duration duration = Duration.between(createdTimeByCode, timeFoundSystem);
			Duration maxDuration = Duration.ofMinutes(2);
			if (duration.abs().compareTo(maxDuration) <= 0) {
				System.out.println("The timestamps are within 2 minutes of each other.");
				reportHelper.onTestSuccess(test,
						"Expected " + msg + " at time : " + sysTimeDate + " Actual updated at : " + timeFoundSystem);
			} else {
				reportHelper.onTestFailure(test,
						"Expected " + msg + " at time : " + sysTimeDate + " Actual udpated at : " + timeFoundSystem);
			}

		} catch (Exception e) {
			reportHelper.generateLog(test,
					"Unexpected error encountered in compareUserAndTimestamps : " + e.getMessage());
		}

		try {
			reportHelper.performAssert(test, msg + " by", loggedInUserName, actionBy);
		} catch (IOException e) {
			reportHelper.generateLog(test,
					"Unexpected error encountered in compareUserAndTimestamps : " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void compareUserAndTimestampsNew(String actionAt, String actionBy, String msg) throws IOException {

		// Compare "actionBy" (user)
		try {
			reportHelper.performAssert(test, msg + " by", loggedInUserName, actionBy);
		} catch (IOException e) {
			// reportHelper.generateLog(test, "Unexpected error encountered in
			// compareUserAndTimestamps: " + e.getMessage());
			reportHelper.onTestFailure(test, "Unexpected error encountered in Compare user: " + e.getMessage());

			e.printStackTrace();
		}

		try {
			// Handle both formats (with 'T' and without seconds)
			DateTimeFormatter formatterWithSeconds = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			DateTimeFormatter formatterWithoutSeconds = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
			DateTimeFormatter isoFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME; // Handles "T"

			LocalDateTime timeFoundSystem;
			try {
				if (actionAt.contains("T")) {
					timeFoundSystem = LocalDateTime.parse(actionAt, isoFormatter); // Parse ISO format
				} else if (actionAt.length() == 16) {
					timeFoundSystem = LocalDateTime.parse(actionAt, formatterWithoutSeconds); // Without seconds
				} else {
					timeFoundSystem = LocalDateTime.parse(actionAt, formatterWithSeconds); // With seconds
				}
			} catch (DateTimeParseException e) {
				throw new IOException("Failed to parse actionAt timestamp: " + actionAt, e);
			}

			// Parse sysTimeDate with seconds
			LocalDateTime createdTimeByCode;
			try {
				createdTimeByCode = LocalDateTime.parse(sysTimeDate, formatterWithSeconds);
			} catch (DateTimeParseException e) {
				throw new IOException("Failed to parse sysTimeDate timestamp: " + sysTimeDate, e);
			}

			// Compare timestamps
			Duration duration = Duration.between(createdTimeByCode, timeFoundSystem);
			Duration maxDuration = Duration.ofMinutes(2);
			if (duration.abs().compareTo(maxDuration) <= 0) {
				System.out.println("The timestamps are within 2 minutes of each other.");
				reportHelper.onTestSuccess(test,
						"Expected " + msg + " at time : " + sysTimeDate + " Actual updated at : " + timeFoundSystem);
			} else {
				reportHelper.onTestFailure(test,
						"Expected " + msg + " at time : " + sysTimeDate + " Actual updated at : " + timeFoundSystem);
			}
		} catch (IOException e) {
			// reportHelper.generateLog(test, "Error in compareUserAndTimestamps: " +
			// e.getMessage());
			reportHelper.onTestFailure(test, "Error in compareUserAndTimestamps: " + e.getMessage());
			throw e;
		} catch (Exception e) {
			// reportHelper.generateLog(test, "Unexpected error encountered in
			// compareUserAndTimestamps: " + e.getMessage());
			reportHelper.onTestFailure(test,
					"Unexpected error encountered in compareUserAndTimestamps: " + e.getMessage());

		}

	}

	public static boolean isFieldReadonly(WebElement element) {
		WebElement element1 = element;

		// Check if the 'readonly' attribute is present
		String readonlyAttribute = element1.getAttribute("readonly");

		// If 'readonly' attribute is present, return true
		return readonlyAttribute != null && readonlyAttribute.equals("true");
	}

	public void saveAndUpdateActionNew(ExtentTest test, WebElement saveBtn, String expectedOutput) throws Throwable {

		tostifyMessage = null;
		errorMessage = null;
		String alertMessage = null;

		boolean isToastMessage = false;
		boolean isTooltipMessage = false;
		boolean isSmallTagMessage = false;
		boolean isAlertMessage = false;

		reportHelper.generateLogWithScreenshot(test, "Before save");

		Thread.sleep(2000);
		genericHelper.scrollingTillWebElement(saveBtn);
		genericHelper.clickWithjavascriptExecutor(saveBtn);

		// Record system date-time for validation
		DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		sysTimeDate = timeFormat.format(LocalDateTime.now());

		try {
			// Check Toastify Message
			// tostifyMessage = getTemporaryElementMessage(getToastifyElement());

			// if (tostifyMessage != null) {
			// isToastMessage = true;
			// } else {
			// // If no toast message, check for tooltip and small tag messages
			// isTooltipMessage = validateInputFields(test, expectedOutput);
			//
			// if (!isTooltipMessage) {
			// isSmallTagMessage = validateErrorMessages(test, expectedOutput);
			// }
			// }

			// isAlertMessage = handleAlertMessage(test, expectedOutput);
			//
			// if (!isAlertMessage) {
			// // Check Toastify Message
			// tostifyMessage = getTemporaryElementMessage(getToastifyElement());
			// if (tostifyMessage != null) {
			// isToastMessage = true;
			// } else {
			// // If no toast message, check for tooltip and small tag messages
			// isTooltipMessage = validateInputFields(test, expectedOutput);
			// if (!isTooltipMessage) {
			// isSmallTagMessage = validateErrorMessages(test, expectedOutput);
			// }
			// }
			// }

			isAlertMessage = handleAlertMessage(test, alertMessage);

			if (!isAlertMessage) {
				// Handle Toastify Messages
				try {
					tostifyMessage = getTemporaryElementMessage(getToastifyElement());
					if (tostifyMessage != null) {
						isToastMessage = true;
					}
				} catch (Exception e) {
					reportHelper.generateLog(test, "No Toastify message found: " + e.getMessage());
				}

				// Handle Tooltip Messages
				try {
					if (!isToastMessage) {
						isTooltipMessage = validateInputFields(test, expectedOutput);
					}
				} catch (Exception e) {
					reportHelper.generateLog(test, "No Tooltip validation message found: " + e.getMessage());
				}

				// Handle Small Tag Messages
				try {
					if (!isTooltipMessage) {
						isSmallTagMessage = validateErrorMessages(test, expectedOutput);
					}
				} catch (Exception e) {
					reportHelper.generateLog(test, "No Small Tag error message found: " + e.getMessage());
				}
			}

			// Handle messages based on flags
			switch (getMessageType(isAlertMessage, isToastMessage, isTooltipMessage, isSmallTagMessage)) {
			case "ALERT":
				handleAlertMessage(test, alertMessage);
				break;
			case "TOAST":
				handleToastifyMessage(test, expectedOutput);
				break;
			case "TOOLTIP":
				validateInputFields(test, expectedOutput);
				reportHelper.generateLog(test, "Tooltip validation message(s) found.");
				break;
			case "SMALL_TAG":
				reportHelper.generateLog(test, "Small tag error message(s) found.");
				break;
			default:
				reportHelper.onTestFailure(test,
						"Deafult - No valid messages found. Expected output : " + expectedOutput);
				break;
			}
		} catch (Exception e) {
			reportHelper.onTestFailure(test, "Catch - No valid messages found.");

			reportHelper.generateLogFullScreenSS(test, e.getMessage());

		} finally {
			driver.navigate().refresh();
		}
	}

	/**
	 * Determine the message type based on the flags
	 */
	private String getMessageType(boolean isAlertMessage, boolean isToastMessage, boolean isTooltipMessage,
			boolean isSmallTagMessage) {
		if (isAlertMessage)
			return "ALERT";
		if (isToastMessage)
			return "TOAST";
		if (isTooltipMessage)
			return "TOOLTIP";
		if (isSmallTagMessage)
			return "SMALL_TAG";
		return "NONE";
	}

	private boolean handleAlertMessage(ExtentTest test, String expectedOutput) throws Throwable {
		try {
			// Switch to the alert and get its message
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			alert.accept(); // Accept the alert after reading the message
			if (alertText != null && !alertText.isEmpty()) {
				reportHelper.performAssert(test, "Alert Message", expectedOutput, alertText);
				reportHelper.generateLogWithScreenshot(test, "Alert message detected: " + alertText);
				return true; // Alert message found and handled
			}
		} catch (NoAlertPresentException e) {
			// No alert present, handle silently
		}
		return false; // No alert found
	}

	/**
	 * Get Toastify element for validation
	 */
	private WebElement getToastifyElement() {
		try {
			return mediumWait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//div[@class='Toastify__toast-body']/div[text()]")));
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * Handle Toastify messages
	 * 
	 * @throws IOException
	 */
	private void handleToastifyMessage(ExtentTest test, String expectedOutput) throws IOException {
		System.out.println("Toastify message detected: " + tostifyMessage);
		if (tostifyMessage.toLowerCase().contains(expectedOutput.toLowerCase())) {
			try {
				reportHelper.onTestSuccess(test, tostifyMessage);
				reportHelper.performAssert(test, "Output", expectedOutput, tostifyMessage);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// try {
			// reportHelper.performAssert(test, "Record Status", expectedOutput,
			// tostifyMessage);
			// } catch (IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
		} else {
			reportHelper.performAssert(test, "Output", expectedOutput, tostifyMessage.trim());
			reportHelper.generateLogWithScreenshot(test, tostifyMessage);
		}
	}

	/**
	 * Validate input fields for validation messages
	 * 
	 * @throws IOException
	 */
	private boolean validateInputFields(ExtentTest test, String expectedOutput) throws IOException {
		List<WebElement> inputFields = driver.findElements(By.cssSelector("input, select, textarea"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		boolean isTooltipMessage = false;

		for (WebElement field : inputFields) {
			String validationMessage = (String) js.executeScript("return arguments[0].validationMessage;", field);
			if (validationMessage != null && !validationMessage.isEmpty()) {
				isTooltipMessage = true;
				reportHelper.performAssert(test, "Validation Error", expectedOutput, validationMessage);
				// reportHelper.generateLog(test, "Validation message for field " +
				// field.getAttribute("name") + ": " + validationMessage);
				reportHelper.generateLogWithScreenshot(test,
						"Validation message for field " + field.getAttribute("name") + ": " + validationMessage);

				System.out.println("Validation message for field : " + validationMessage);

			}
		}
		return isTooltipMessage;
	}

	/**
	 * Validate error messages in small tags
	 */
	private boolean validateErrorMessages(ExtentTest test, String expectedOutput) {
		try {
			// WebElement errorElement =
			// shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("small,div")));
			// WebElement errorElement =
			// shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//small
			// | //div")));
			// WebElement errorElement =
			// shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//small")));
			WebElement errorElement = shortWait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//small[contains(@class,'danger')]")));

			errorMessage = errorElement.getText();

			if (errorMessage != null && !errorMessage.isEmpty()) {
				reportHelper.performAssert(test, "Error Message", expectedOutput, errorMessage);
				reportHelper.generateLogWithScreenshot(test, "Error message: " + errorMessage);
				System.out.println("Error message: " + errorMessage);
				return true;

				// errorElement =
				// shortWait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("small")));
				// errorMessage= errorElement.getText();
				//
				// if (errorMessage != null && !errorMessage.isEmpty()) {
				// reportHelper.performAssert(test, "Error message", expectedOutput,
				// errorMessage);
				// System.out.println("Validation message " + errorMessage);
				// }
			}
		} catch (Exception e) {
			// No small tag error found, handle silently
		}
		return false;
	}

	// public void asd()
	// {
	// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd
	// HH:mm:ss");
	// LocalDateTime timeFoundSystem = LocalDateTime.parse(updatedAt, formatter);
	//
	// //change sysTimeDate to format
	// LocalDateTime createdTimeByCode = LocalDateTime.parse(sysTimeDate,
	// formatter);
	//
	// //Compare sysTimeDate and grid time
	// Duration duration = Duration.between(createdTimeByCode,timeFoundSystem);
	// Duration maxDuration = Duration.ofMinutes(1);
	// if (duration.abs().compareTo(maxDuration) <= 0)
	// {
	// System.out.println("The timestamps are within 2 minutes of each other.");
	// reportHelper.onTestSuccess(test, "Expected udpated at time : "+sysTimeDate+"
	// Actual updated at : "+timeFoundSystem);
	// }
	// else
	// {
	// reportHelper.onTestFailure(test, "Expected udpated at time : "+sysTimeDate+"
	// Actual udpated at : "+timeFoundSystem);
	// }
	//
	// reportHelper.generateLogFullScreenSS(test, " user uppdated successfully and
	// record displayed in grid");
	// }

	public void clearDropdownWithJS(WebDriver driver, String xpath, String tagName) {
		// JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

		// JavaScript to find all elements matching the tag name inside SVGs located by
		// the XPath
		String script = "var svgElements = document.evaluate(arguments[0], document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);"
				+ "var elements = [];" + "for (var i = 0; i < svgElements.snapshotLength; i++) {"
				+ "  var svg = svgElements.snapshotItem(i);"
				+ "  var tagElements = svg.getElementsByTagName(arguments[1]);"
				+ "  for (var j = 0; j < tagElements.length; j++) {" + "    elements.push(tagElements[j]);" + "  }"
				+ "}" + "return elements;";

		// Execute the JavaScript code and get a list of matching elements
		List<WebElement> foundElements = (List<WebElement>) js.executeScript(script, xpath, tagName);

		// Check the size of the found elements
		if (foundElements != null && !foundElements.isEmpty()) {
			System.out.println("Found " + foundElements.size() + " " + tagName + " elements.");

			// Example action: Click on the first found element
			foundElements.get(0).click();
			System.out.println("Clicked on the first " + tagName + " element.");
		} else {
			System.out.println("No " + tagName + " elements found.");
		}
	}
}
