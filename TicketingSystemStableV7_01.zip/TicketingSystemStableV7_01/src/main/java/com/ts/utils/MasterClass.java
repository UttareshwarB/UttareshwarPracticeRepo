package com.ts.utils;

import java.io.IOException;
import org.openqa.selenium.By;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.sharedutils.*;

public class MasterClass extends ProjectFunctions {

	@BeforeSuite(alwaysRun = true)
	public void preSuiteHandler() throws Exception {

		masterDto.setAttribute("qaName", qaName);
		masterDto.setAttribute("docTitle", docTitle);
		masterDto.setAttribute("reportName", reportName);

		extentReports = reportHelper.generateReport(masterDto);
		test = extentReports.createTest("Setup");

		String browser = "chrome";
		driver = genericHelper.startBrowser(browser);

		String url = propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE, "2TestingURL");

		// String url =
		// propertyHelper.readDataFromPropertyFile(GlobalConstants.CONFIG_FILE,
		// "softLaunch");
		genericHelper.navigateToURL(test, url);

		driver.findElement(By.xpath("//button[.='Continue to site']")).click();

		pageInitialiazation(driver);
		
		if (!isLoggedIn) {
			login();
			isLoggedIn = true; // Mark that login has been done
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodHandler(ITestResult result) {
		// Initialize row index for each test case before the method runs
//		String testCaseName = result.getMethod().getMethodName();
//		if (!testRowIndexMap.containsKey(testCaseName)) {
//			// Get row index dynamically (ensure it’s based on your Excel data structure)
//			int rowIndex = getRowIndexForTestCase(testCaseName);
//			testRowIndexMap.put(testCaseName, rowIndex);
//		}
	}

	@AfterMethod(alwaysRun = true)
	public void postMethodHandler(ITestResult result) throws IOException, Exception {
		reportHelper.tearDown(test, result);
		extentReports.flush();
	}

	@AfterSuite(alwaysRun = true)
	public void postSuiteHandler() throws IOException, Exception {
		isLoggedIn = false;
	}

}
