package com.ts.core;

import org.apache.commons.lang3.StringUtils;

import com.sharedutils.MasterDto;
import com.ts.utils.MasterClass;

public class DepartmentMaster extends MasterClass  {

	//Declare Variable Globally
	String departmentName;
	String remark;  
	String status; 

	String addSuccessMsg = "Department created successfully";   
	String updateSuccessMsg = "Department updated successfully";  

	public void addDepartment(MasterDto masterDto) throws Throwable {    
		// Navigate to Status Master Page

		try {
			String expectedOutput = masterDto.getAttributeValue("Expected Output"); //store value in expectedOutput from excelsheet

			test = reportHelper.createTestCase(test, extentReports, masterDto); 

			navigateToPage.departmentMaster();

			// Extract values from MasterDto(Excel)
			departmentName = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Department Name "), "");  
			remark = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Remark"), "");
			//	expectedOutput = masterDto.getAttributeValue("Expected Output");

			// Log details


			// Interact with the StatusMasterPage elements
			departmentMasterPage.addDepartment().click();
			reportHelper.generateLogFullScreenSS(test, "Add department page");  //For taking Screenshot

			reportHelper.generateLog(test, "Department Name : " + departmentName);  
			reportHelper.generateLog(test, "Remark : " + remark);
			reportHelper.generateLog(test, "Expected output : " + expectedOutput);

			departmentMasterPage.departmentName().sendKeys(departmentName);
			departmentMasterPage.deptRemark().sendKeys(remark);

			// Save or cancel based on expected output
			//saveAndUpdateActionUpdated4(test, departmentMasterPage.submit(),  expectedOutput); 

			saveAndUpdateActionNew(test, departmentMasterPage.submit(), expectedOutput);

			//		} catch (Exception e) {
			//			reportHelper.generateLog(test, "Exception while adding status: " + e.getMessage());
			//		}

			try 
			{
				// Validate success message and grid details
				if (expectedOutput.contains(addSuccessMsg) && tostifyMessage.contains(addSuccessMsg)) {

					String sr = departmentMasterPage.SrNo().getText();
					String displayeEditBtn = departmentMasterPage.editBtn().getAttribute("data-bs-target");
					String departmentName = departmentMasterPage.viewDepartment().getText();
					String viewStatus = departmentMasterPage.viewStatus().getText();
					String createdAt = departmentMasterPage.viewCreatedAt().getText();
					String createdBy = departmentMasterPage.viewCreatedBy().getText();
					//				String updatedAt = statusMasterPage.viewUpdatedAt().getText();
					//				String updatedBy = statusMasterPage.viewUpdatedBy().getText(); 

					reportHelper.performAssert(test, "Serial Number", "1", sr);
					//reportHelper.performAssert(test, "Action", "#edit", displayeEditBtn);
					reportHelper.performAssert(test, "Department Name ", departmentName, departmentName);
					reportHelper.performAssert(test, "Status", "Active", viewStatus);
					//				reportHelper.performAssert(test, "Created By", loggedInUserName, createdBy);
					//				reportHelper.performAssert(test, "Updated By", loggedInUserName, updatedBy);

					// Validate timestamps
					String updatedAt = departmentMasterPage.viewUpdatedAt().getText(); 
					String updatedBy = departmentMasterPage.viewUpdatedBy().getText(); 

					compareUserAndTimestampsNew(createdAt, createdBy, "Created");

					reportHelper.performAssert(test, "Updated at", "", updatedAt);
					reportHelper.performAssert(test, "Updated by", "", updatedBy);					//reportHelper.performAssert(test, "Updated By", loggedInUserName, updatedBy);
					reportHelper.generateLogFullScreenSS(test, "Department added successfully and verified in the grid.");
				}
			}

			catch (Exception e) {
				reportHelper.generateLog(test, "Unexpected error encountered: " + e.getMessage());  
			}
		}

		catch (Exception e) {
			reportHelper.onTestFailure(test, "TIme out exception");

			System.out.println("Unexpected error encountered in department master page: " + e.getMessage());

		}
	}
	public void editDepartment(MasterDto masterDto) throws Throwable {

		try {
			String expectedOutput = masterDto.getAttributeValue("Expected Output");
			String search = masterDto.getAttributeValue("Search");
			departmentName = masterDto.getAttributeValue("Department Name");
			remark = masterDto.getAttributeValue("Remark");
			status = masterDto.getAttributeValue("Status");

			boolean editDepartmentName = false;
			boolean editRemark = false;
			boolean editStatus = false; 


			// Create test case in the report
			test = reportHelper.createTestCase(test, extentReports, masterDto);

			// Navigate to Status Master Page
			navigateToPage.departmentMaster();

			// Search for the record
			searchData(search);

			reportHelper.generateLogFullScreenSS(test, "Edit Department Page");

			if (departmentMasterPage.gridFirstRow().isDisplayed()) { 
				String gridDepartmetnName = departmentMasterPage.viewDepartment().getText().trim();
				reportHelper.performAssert(test, "Search Result", search, gridDepartmetnName);

				if (search.equalsIgnoreCase(gridDepartmetnName)) {
					// Click Edit Button
					departmentMasterPage.editBtn().click();
					Thread.sleep(3000);
					reportHelper.generateLogWithScreenshot(test, "Department edit page");
					reportHelper.generateLog(test, "Department Name: " + departmentName);
					reportHelper.generateLog(test, "Remark: " + remark);
					reportHelper.generateLog(test, "Status: " + status);
					reportHelper.generateLog(test, "Expected output: " + expectedOutput); 

					// Edit Department Name
					if (departmentName != null) {
						editDepartmentName = true;
						Thread.sleep(2000);
						if (departmentName.equalsIgnoreCase("blank")) {
							departmentName="";
							clearWithActions(departmentMasterPage.departmentName());
						} else {
							clearAndSendkeysWithActions(departmentMasterPage.departmentName(), departmentName);
						}
					}

					// Edit Remark
					if (remark != null) {
						editRemark = true;
						Thread.sleep(2000);
						if (remark.equalsIgnoreCase("blank")) {
							remark="";
							clearWithActions(departmentMasterPage.deptRemark());
						} else {
							clearAndSendkeysWithActions(departmentMasterPage.deptRemark(), remark);
						}
					}

					// Edit Status (Active/Deactive)
					if (status != null) {
						editStatus = true;
						statusSelection(departmentMasterPage.activeStatus(), departmentMasterPage.deactiveStatus(), status);
					}

					// Save changes
					//	saveAndUpdateActionUpdated4(test, departmentMasterPage.update(), expectedOutput);

					saveAndUpdateActionNew(test, departmentMasterPage.update(), expectedOutput);

				} else {
					reportHelper.generateLog(test, "Search failed, no matching record found.");
				}
			} else {
				reportHelper.generateLog(test, "No data found.");
				reportHelper.generateLog(test, "Expected output: " + expectedOutput);
			}

			// Validation after update
			if (tostifyMessage.trim().contains(updateSuccessMsg) && expectedOutput.trim().contains(updateSuccessMsg)) {
				searchData(editDepartmentName ? departmentName : search);
				//
				//				if (editStatusName) {
				//					String updatedStatusName = statusMasterPage.viewStatusName().getText();
				//					reportHelper.performAssert(test, "Status Name", this.statusName, updatedStatusName);
				//				}

				if(editDepartmentName)
				{	
					String updatedDepartmentName = departmentMasterPage.viewDepartment().getText();
					reportHelper.performAssert(test, "Department Name", departmentName, updatedDepartmentName);
				} 
				else
				{
					String updatedDepartmentName = departmentMasterPage.viewDepartment().getText();
					reportHelper.performAssert(test, "Department Name", updatedDepartmentName, search);
				}

				//				if (editRemark) {
				//					String updatedRemark = statusMasterPage.view().getText(); 
				//					reportHelper.performAssert(test, "Remark", this.remark, updatedRemark);
				//				}

				if (editStatus) {
					String updatedStatus = departmentMasterPage.viewStatus().getText();
					reportHelper.performAssert(test, "Status", this.status, updatedStatus);
				}

				String updatedAt = departmentMasterPage.viewUpdatedAt().getText();
				String updatedBy = departmentMasterPage.viewUpdatedBy().getText();
				compareUserAndTimestampsNew(updatedAt, updatedBy, "Updated by");

				reportHelper.generateLogFullScreenSS(test, "Record updated successfully and displayed in the grid.");
			}

		} catch (Exception e) {
			reportHelper.onTestFailure(test, "Exception: " + e.getMessage());
			reportHelper.generateLogFullScreenSS(test, "Issue: " + e.getMessage());
		}
	}

}
