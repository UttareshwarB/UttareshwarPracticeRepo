package com.ts.core;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.sharedutils.MasterDto;
import com.ts.utils.MasterClass;

public class CountryMaster extends MasterClass {

	String country;

	String remark;
	String status;

	// String addSuccessMsg = "Record Inserted !!!";
	// String updateSuccessMsg = "Record Updated !!!";
	String addSuccessMsg = "Country created successfully";
	String updateSuccessMsg = "Country updated successfully";

	// @Test
	public void addCounty(MasterDto masterDto) throws Throwable {
		Thread.sleep(1000);

		navigateToPage.countryMasterPage();

		// if(homePage.countryMaster().isDisplayed()) {
		//
		// homePage.countryMaster().click();
		//
		// } else {
		//
		// homePage.master().click();
		// Thread.sleep(1000);
		//
		// homePage.countryMaster().click();
		//

		String country = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Country"), "");
		String remark = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Remark"), "");
		// remark = genericHelper.handleNullString(remark);
		String expectedOutput = masterDto.getAttributeValue("Expected Output");
		test = reportHelper.createTestCase(test, extentReports, masterDto);

		reportHelper.generateLogWithScreenshot(test, "Country Master page");

		try {

			countryMasterPage.addCountry().click();

			reportHelper.generateLogWithScreenshot(test, "Country add page");
			reportHelper.generateLog(test, "Country :" + country);
			reportHelper.generateLog(test, "Remark :" + remark);

			genericHelper.insertDataIntoField(countryMasterPage.country(), masterDto.getAttributeValue("Country"));
			genericHelper.insertDataIntoField(countryMasterPage.remark(), masterDto.getAttributeValue("Remark"));

			reportHelper.generateLogWithScreenshot(test, "Before save");

			saveAndUpdateActionNew(test, commonFields.addBtn(), expectedOutput);

		} catch (Exception e) {
			reportHelper.generateLog(test, "Exception : " + e);
		}

		driver.navigate().refresh();
		String sucessMsg = "Record Inserted !!!";

		if (expectedOutput.contains(addSuccessMsg) && tostifyMessage.contains(addSuccessMsg)) {
			String action = countryMasterPage.viewAction().getAttribute("data-bs-target");

			reportHelper.performAssert(test, "Action", "#edit", action);
			reportHelper.performAssert(test, "Sr no", "1", countryMasterPage.viewSrno().getText());
			reportHelper.performAssert(test, "County", country, countryMasterPage.viewCountry().getText());
			reportHelper.performAssert(test, "Status", "Active", countryMasterPage.viewStatus().getText());
			// reportHelper.performAssert(test, "Created By", createdBy,
			// countryMasterPage.viewCreatedBy().getText());

			String createdAt = countryMasterPage.viewCreatedBy().getText();
			// Change grid time to format
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			LocalDateTime timeFoundSystem = LocalDateTime.parse(createdAt, formatter);

			// change sysTimeDate to format
			LocalDateTime createdTimeByCode = LocalDateTime.parse(sysTimeDate, formatter);

			// Compare sysTimeDate and grid time
			Duration duration = Duration.between(createdTimeByCode, timeFoundSystem);
			Duration maxDuration = Duration.ofMinutes(1);
			if (duration.abs().compareTo(maxDuration) <= 0) {
				System.out.println("The timestamps are within 2 minutes of each other.");
				reportHelper.onTestSuccess(test,
						"Expected created at time : " + sysTimeDate + " Actual created at : " + timeFoundSystem);
			} else {
				reportHelper.onTestFailure(test,
						"Expected created at time : " + sysTimeDate + " Actual created at : " + timeFoundSystem);
			}

			reportHelper.generateLogFullScreenSS(test, " user added successfully and record displayed on First line");
		} else {
			reportHelper.generateLog(test, "No data found");
			reportHelper.generateLog(test, "Expected output : " + expectedOutput);
		}

	}

	/*
	 * @Test public void editCounty(MasterDto masterDto) throws
	 * InterruptedException, Exception {
	 * 
	 * Thread.sleep(1000); navigateToPage.countryMasterPage();
	 * 
	 * String country = masterDto.getAttributeValue("Country"); String searchCountry
	 * = masterDto.getAttributeValue("Search"); String remark =
	 * masterDto.getAttributeValue("Remark"); // remark =
	 * genericHelper.handleNullString(remark); String expectedOutput =
	 * masterDto.getAttributeValue("Expected Output"); String status =
	 * masterDto.getAttributeValue("Status");
	 * 
	 * test = reportHelper.createTestCase(test, extentReports, masterDto);
	 * 
	 * reportHelper.generateLogWithScreenshot(test, "Country Master page"); try {
	 * test = reportHelper.createTestCase(test, extentReports, masterDto);
	 * 
	 * searchData(searchCountry);
	 * 
	 * // genericHelper.insertDataIntoField(commonFields.searchField(),
	 * searchCountry); // // commonFields.searchBtn().click();
	 * 
	 * String countryName =
	 * driver.findElement(By.xpath("//div[contains(@class,'TableRow')]/div[3]/div"))
	 * .getText();
	 * 
	 * if (driver.findElement(By.xpath("//div[contains(@class,'TableRow')]")).
	 * isDisplayed()) {
	 * 
	 * reportHelper.performAssert(test, "Country name", searchCountry, countryName);
	 * 
	 * if (searchCountry.equalsIgnoreCase(countryName)) {
	 * 
	 * countryMasterPage.editBtn().click(); if (country != null &&
	 * !country.isEmpty()) {
	 * 
	 * genericHelper.insertDataIntoField(countryMasterPage.country(), country); }
	 * 
	 * if (remark != null && !remark.isEmpty()) {
	 * 
	 * genericHelper.insertDataIntoField(countryMasterPage.remark(), remark); }
	 * 
	 * if (status != null && !status.isEmpty()) {
	 * 
	 * statusSelection(stateMasterPage.activeStatus(),
	 * stateMasterPage.deactiveStatus(), status);
	 * 
	 * }
	 * 
	 * reportHelper.generateLogFullScreenSS(test, "Before Save");
	 * 
	 * saveAndUpdateAction(test, commonFields.updateBtn(), commonFields.cancelBtn(),
	 * expectedOutput);
	 * 
	 * 
	 * driver.navigate().refresh();
	 * 
	 * 
	 * String msg ="Record Updated !!!";
	 * 
	 * 
	 * if (tostifyMessage.contains(msg)) { String action =
	 * countryMasterPage.viewAction().getAttribute("class");
	 * 
	 * reportHelper.performAssert(test, "Action", "edit", action);
	 * reportHelper.performAssert(test, "Sr no", "1",
	 * countryMasterPage.viewSrno().getText()); reportHelper.performAssert(test,
	 * "County", country, countryMasterPage.viewCountry().getText());
	 * reportHelper.performAssert(test, "Status", "Active",
	 * countryMasterPage.viewStatus().getText()); reportHelper.performAssert(test,
	 * "Updated By", updatedBy, countryMasterPage.viewUpdatedBy().getText()); String
	 * updatedAt = genericHelper.getCurrentDateTimeToField("yyyy-MM-dd HH:mm");
	 * if(countryMasterPage.viewUpdatedAt().getText().contains(updatedAt)) {
	 * reportHelper.performAssert(test, "Updated At", updatedAt,
	 * countryMasterPage.viewUpdatedAt().getText()); } } else { //
	 * reportHelper.generateLog(test, "No data found"); //
	 * reportHelper.generateLog(test, "Expected output : "+expectedOutput); }
	 * 
	 * }
	 * 
	 * else { reportHelper.generateLog(test, "Search failed"); } } else {
	 * reportHelper.generateLog(test, "No data found");
	 * reportHelper.generateLog(test, "Expected output : "+expectedOutput); } }
	 * catch (Exception e) { reportHelper.generateLog(test, "Exception : "+e); } }
	 * 
	 * @Test public void gridViewCounty(MasterDto masterDto) throws
	 * InterruptedException, Exception {
	 * 
	 * navigateToPage.countryMasterPage(); Thread.sleep(1000);
	 * 
	 * String expectedCountry =
	 * StringUtils.defaultIfBlank(masterDto.getAttributeValue("Country"), "");
	 * String searchCountry =
	 * StringUtils.defaultIfBlank(masterDto.getAttributeValue("Search"), "");
	 * //String remark =
	 * StringUtils.defaultIfBlank(masterDto.getAttributeValue("Remark"), ""); //
	 * remark = genericHelper.handleNullString(remark); String expectedOutput =
	 * masterDto.getAttributeValue("Expected Output"); String expectedStatus =
	 * masterDto.getAttributeValue("Status");
	 * 
	 * test = reportHelper.createTestCase(test, extentReports, masterDto);
	 * 
	 * searchData(searchCountry);
	 * 
	 * if (driver.findElement(By.xpath("//div[contains(@class,'TableRow')]")).
	 * isDisplayed()) {
	 * 
	 * //reportHelper.performAssert(test, "Country name", searchCountry,
	 * countryName);
	 * 
	 * 
	 * 
	 * String actualCountry = countryMasterPage.viewCountry().getText(); String
	 * actualStatus = countryMasterPage.viewStatus().getText(); String
	 * actualCreatedBy = countryMasterPage.viewCreatedBy().getText(); String
	 * actualCreatedAt = countryMasterPage.viewCreatedAt().getText(); String
	 * actualUpdatedAt = countryMasterPage.viewUpdatedAt().getText(); String
	 * actualUpdatedBy = countryMasterPage.viewUpdatedBy().getText();
	 * 
	 * System.out.println(actualCountry + actualStatus); Thread.sleep(1000);
	 * 
	 * reportHelper.performAssert(test, "Country", expectedCountry, actualCountry);
	 * 
	 * //genericHelper.compareStrings(expectedCountry, actualCountry);
	 * 
	 * reportHelper.performAssert(test, "Status", expectedStatus, actualStatus);
	 * 
	 * if(actualCreatedBy.toLowerCase().contains(createdBy.toLowerCase()) ||
	 * actualCreatedBy.toLowerCase().contains(username.toLowerCase())) {
	 * reportHelper.generateLog(test,
	 * "Expected Created by : "+createdBy+" or "+username+"Actual Created by : "
	 * +actualCreatedBy); } else { reportHelper.generateLog(test,
	 * "Expected Created by : "+createdBy+" or "+username+"Actual Created by : "
	 * +actualCreatedBy); }
	 * 
	 * reportHelper.generateLog(test, "Created At : "+actualCreatedAt);
	 * 
	 * if(actualUpdatedBy.toLowerCase().contains(updatedBy.toLowerCase()) ||
	 * actualUpdatedBy.toLowerCase().contains(username.toLowerCase())) {
	 * reportHelper.generateLog(test,
	 * "Expected Updated by : "+updatedBy+" or "+username+"Actual Updated by : "
	 * +actualUpdatedBy);
	 * 
	 * }
	 * 
	 * else { reportHelper.generateLog(test,
	 * "Expected Updated by : "+updatedBy+" or "+username+"Actual Updated by : "
	 * +actualUpdatedBy); }
	 * 
	 * reportHelper.generateLog(test, "Updated At : "+actualUpdatedAt); }
	 * //genericHelper.compareStrings(expectedStatus, actualStatus);
	 * 
	 * else { reportHelper.generateLog(test, "No data found");
	 * reportHelper.generateLog(test, "Expected output : "+expectedOutput); }
	 * reportHelper.generateLog(test, "Expected Output : "+expectedOutput);
	 * 
	 * 
	 * 
	 * }
	 */

	public void addCountry(ExtentTest test, MasterDto masterDto) throws Throwable {

		try {

			navigateToPage.countryMasterPage();

			// String country = masterDto.getAttributeValue("Country");
			country = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Country"), "");
			// masterDto.getAttributeValue("State");

			// state = genericHelper.handleNullString(state);

			remark = StringUtils.defaultIfBlank(masterDto.getAttributeValue("Remark"), "");
			// remark = genericHelper.handleNullString(remark);
			String expectedOutput = masterDto.getAttributeValue("Expected Output");

			reportHelper.generateLogWithScreenshot(test, "Country Master page");

			try {

				countryMasterPage.addCountry().click();

				reportHelper.generateLogWithScreenshot(test, "Country add page");
				reportHelper.generateLog(test, "Country :" + country);

				reportHelper.generateLog(test, "Remark :" + remark);
				reportHelper.generateLog(test, "Expected output :" + expectedOutput);

				countryMasterPage.country().sendKeys(country);
				countryMasterPage.remark().sendKeys(remark);

				// saveAndUpdateActionUpdated3(test, countryMasterPage.addButton(),
				// countryMasterPage.cancelButton(), expectedOutput);

				saveAndUpdateActionNew(test, countryMasterPage.addButton(), expectedOutput);
			}

			catch (Exception e) {
				reportHelper.generateLog(test, "Exception : " + e);
			}

			try {

				if (tostifyMessage.equalsIgnoreCase(addSuccessMsg) && expectedOutput.equalsIgnoreCase(addSuccessMsg)) {
					String action = countryMasterPage.viewAction().getAttribute("data-bs-target");

					reportHelper.performAssert(test, "Action", "#depedit", action);
					reportHelper.performAssert(test, "Sr no", "1", countryMasterPage.viewSrno().getText());
					reportHelper.performAssert(test, "County", country, countryMasterPage.viewCountry().getText());
					// reportHelper.performAssert(test, "State", state,
					// stateMasterPage.viewState().getText());

					String createdAt = countryMasterPage.viewCreatedAt().getText();
					String createdBy = countryMasterPage.viewCreatedBy().getText();
					String updatedAt = countryMasterPage.viewUpdatedAt().getText();
					String updatedBy = countryMasterPage.viewUpdatedBy().getText();

					reportHelper.performAssert(test, "Status", "Active", countryMasterPage.viewStatus().getText());
					// reportHelper.performAssert(test, "Created By", createdBy,
					// stateMasterPage.viewCreatedBy().getText());
					// String createdAt = genericHelper.getCurrentDateTimeToField("yyyy-MM-dd
					// HH:mm");
					//
					// if(stateMasterPage.viewCreatedAt().getText().contains(createdAt))
					// {
					// reportHelper.performAssert(test, "Created At", createdAt,
					// countryMasterPage.viewCreatedAt().getText());
					// }
					// reportHelper.performAssert(test, "Creator Name ",loggedInUserName
					// ,createdBy);

					compareUserAndTimestamps(createdAt, createdBy, "Created");

					reportHelper.performAssert(test, "Updated at", "", updatedAt);
					reportHelper.performAssert(test, "Updated by", "", updatedBy);

					// Change grid time to format
					// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd
					// HH:mm:ss");
					// LocalDateTime timeFoundSystem = LocalDateTime.parse(createdAt, formatter);
					//
					// //change sysTimeDate to format
					// LocalDateTime createdTimeByCode = LocalDateTime.parse(sysTimeDate,
					// formatter);
					//
					// //Compare sysTimeDate and grid time
					// Duration duration = Duration.between(createdTimeByCode,timeFoundSystem);
					// Duration maxDuration = Duration.ofMinutes(1);
					// if (duration.abs().compareTo(maxDuration) <= 0)
					// {
					// System.out.println("The timestamps are within 2 minutes of each other.");
					// reportHelper.onTestSuccess(test, "Expected created at time : "+sysTimeDate+"
					// Actual created at : "+timeFoundSystem);
					// }
					// else
					// {
					// reportHelper.onTestFailure(test, "Expected created at time : "+sysTimeDate+"
					// Actual created at : "+timeFoundSystem);
					// }

					reportHelper.generateLogFullScreenSS(test,
							" user added successfully and record displayed on First line");

				} else {
					// reportHelper.generateLog(test, "No data found");
					// reportHelper.generateLog(test, "Expected output : "+expectedOutput);
				}

			} catch (Exception e) {
				reportHelper.generateLog(test, "Exception : " + e);
			}

		} catch (Exception e) {
			reportHelper.onTestFailure(test, "Unexpected error encountered in country master page: " + e.getMessage());
		}
	}

	@Test
	public void editCountry(MasterDto masterDto) throws Throwable {
		try {

			navigateToPage.countryMasterPage();
//			test = reportHelper.createTestCase(test, extentReports, masterDto);
			remark = masterDto.getAttributeValue("Remark");
			// remark = genericHelper.handleNullString(remark);
			String expectedOutput = masterDto.getAttributeValue("Expected Output");
			status = masterDto.getAttributeValue("Status");
			// dto.getAttribute(billCheckingTransactionSheet)

			country = masterDto.getAttributeValue("Country");

			try {

				String search = masterDto.getAttributeValue("Search");
				// masterDto.getAttributeValue("State");

				// state = genericHelper.handleNullString(state);

				boolean editCountry = false;

				boolean editRemark = false;
				boolean editStatus = false;

				searchData(search);

				String countryName = driver.findElement(By.xpath("//div[contains(@class,'TableRow')]/div[3]/div"))
						.getText();

				if (driver.findElement(By.xpath("//div[contains(@class,'TableRow')]")).isDisplayed()) {

					reportHelper.performAssert(test, "Country name", search, countryName);

					if (search.equalsIgnoreCase(countryName)) {

						reportHelper.generateLogWithScreenshot(test, "Search result ");

						countryMasterPage.editBtn().click();

						reportHelper.generateLogWithScreenshot(test, "Country edit page");

						reportHelper.generateLog(test, "Country :" + country);
						reportHelper.generateLog(test, "Remark :" + remark);

						reportHelper.generateLog(test, "Status :" + status);
						reportHelper.generateLog(test, "Expected output :" + expectedOutput);

						if (country != null && !country.isEmpty()) {

							editCountry = true;
							if (country.equalsIgnoreCase("blank")) {
								country = "";
								// countryMasterPage.country().clear();
								clearWithActions(countryMasterPage.country());
								// genericHelper.sendKeysAndEnterWithWait(cityMasterPage.country(), country);
							}

							// countryMasterPage.country().clear();
							//
							// genericHelper.sendKeysAndEnterWithWait(countryMasterPage.country(), country);
							else {
								// genericHelper.insertDataIntoField(countryMasterPage.country(), country);

								clearAndSendkeysWithActions(countryMasterPage.country(), country);
							}

						}

						if (remark != null && !remark.isEmpty()) {

							editRemark = true;

							if (remark.equalsIgnoreCase("blank")) {
								remark = "";
								// countryMasterPage.remark().clear();
								clearWithActions(countryMasterPage.remark());

							} else {

//								countryMasterPage.remark().clear();
//								countryMasterPage.remark().sendKeys(remark);

								clearAndSendkeysWithActions(countryMasterPage.remark(), remark);

							}
						}

						try {

							if (status != null && !status.isEmpty()) {
								editStatus = true;

								statusSelection(countryMasterPage.activeStatus(), countryMasterPage.deactiveStatus(),
										status);

							}

						} catch (Exception e) {
							// TODO: handle exception
						}
						// stateMasterPage.updateBtn().click();

						// saveAndUpdateActionUpdated3(test, countryMasterPage.updateBtn(),
						// countryMasterPage.cancelBtn(), expectedOutput);
						saveAndUpdateActionNew(test, countryMasterPage.updateBtn(), expectedOutput);
					}

					else {
						reportHelper.generateLog(test, "Search failed");
					}
				} else {
					reportHelper.generateLog(test, "No data found");
					reportHelper.generateLog(test, "Expected output : " + expectedOutput);
				}

				try {

					if (tostifyMessage.contains(updateSuccessMsg) && expectedOutput.contains(updateSuccessMsg)) {
						if (editCountry) {
							searchData(country);
						} else {
							searchData(search);
						}

						if (editCountry) {
							String country = countryMasterPage.viewCountry().getText();
							reportHelper.performAssert(test, "Country", this.country, country);
						}

						if (editStatus) {

							// editStatus=true;
							// String status= driver.findElement(By.xpath("//div[contains(@class,
							// 'TableBody')]/child::div[1]/child::div[@data-column-id='6']/div")).getText();
							String status = countryMasterPage.viewStatus().getText();

							reportHelper.performAssert(test, "Status", this.status, status);
						}

						String updatedAt = countryMasterPage.viewUpdatedAt().getText();
						String updatedBy = countryMasterPage.viewUpdatedBy().getText();

						// grid view xpath
						// String isActiveStatus= driver.findElement(By.xpath("//div[contains(@class,
						// 'TableBody')]/child::div[1]/child::div[@data-column-id='6']/child::div/child::span")).getText();
						// String sr= driver.findElement(By.xpath("//div[contains(@class,
						// 'TableBody')]/child::div[1]/child::div[@data-column-id='2']/div")).getText();
						// String state= driver.findElement(By.xpath("//div[contains(@class,
						// 'TableBody')]/child::div[1]/child::div[@data-column-id='4']/div")).getText();

						// Change grid time to format

						compareUserAndTimestampsNew(updatedAt, updatedBy, "Updated");

						// DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd
						// HH:mm:ss");
						// LocalDateTime timeFoundSystem = LocalDateTime.parse(updatedAt, formatter);
						//
						// //change sysTimeDate to format
						// LocalDateTime createdTimeByCode = LocalDateTime.parse(sysTimeDate,
						// formatter);
						//
						// //Compare sysTimeDate and grid time
						// Duration duration = Duration.between(createdTimeByCode,timeFoundSystem);
						// Duration maxDuration = Duration.ofMinutes(1);
						// if (duration.abs().compareTo(maxDuration) <= 0)
						// {
						// System.out.println("The timestamps are within 2 minutes of each other.");
						// reportHelper.onTestSuccess(test, "Expected udpated at time : "+sysTimeDate+"
						// Actual updated at : "+timeFoundSystem);
						// }
						// else
						// {
						// reportHelper.onTestFailure(test, "Expected udpated at time : "+sysTimeDate+"
						// Actual udpated at : "+timeFoundSystem);
						// }

						reportHelper.generateLogFullScreenSS(test,
								" user uppdated successfully and record displayed in grid");

					}

				} catch (Exception e) {
					// TODO: handle exception
				}

			} catch (Exception e) {
				// TODO: handle exception
				reportHelper.generateLogFullScreenSS(test, e.getMessage());
			}

		} catch (Exception e) {
			reportHelper.onTestFailure(test, "Unexpected error encountered: " + e.getMessage());
		}

	}
}

/*
 * String msg ="Record Updated !!!";
 * 
 * if (tostifyMessage.contains(msg)) { String action =
 * countryMasterPage.viewAction().getAttribute("class");
 * 
 * reportHelper.performAssert(test, "Action", "edit", action);
 * reportHelper.performAssert(test, "Sr no", "1",
 * stateMasterPage.viewSrno().getText()); reportHelper.performAssert(test,
 * "County", country, stateMasterPage.viewCountry().getText());
 * reportHelper.performAssert(test, "State", state,
 * stateMasterPage.viewState().getText());
 * 
 * reportHelper.performAssert(test, "Status", "Active",
 * stateMasterPage.viewStatus().getText()); reportHelper.performAssert(test,
 * "Updated By", updatedBy, stateMasterPage.viewUpdatedBy().getText());
 * reportHelper.performAssert(test, "Created By", createdBy,
 * stateMasterPage.viewCreatedBy().getText()); // String createdAt =
 * genericHelper.getCurrentDateTimeToField("yyyy-MM-dd HH:mm"); //
 * if(stateMasterPage.viewCreatedAt().getText().contains(createdAt)) // { //
 * reportHelper.performAssert(test, "Created At", createdAt,
 * countryMasterPage.viewCreatedAt().getText()); // }
 * 
 * String updatedAt =
 * genericHelper.getCurrentDateTimeToField("yyyy-MM-dd HH:mm");
 * if(stateMasterPage.viewUpdatedAt().getText().contains(updatedAt)) {
 * reportHelper.performAssert(test, "Updated At", updatedAt,
 * countryMasterPage.viewUpdatedAt().getText()); } } else { //
 * reportHelper.generateLog(test, "No data found"); //
 * reportHelper.generateLog(test, "Expected output : "+expectedOutput); } }
 * 
 * 
 * 
 * catch (Exception e) { reportHelper.generateLog(test, "Exception : "+e); }
 * 
 * 
 * 
 */
